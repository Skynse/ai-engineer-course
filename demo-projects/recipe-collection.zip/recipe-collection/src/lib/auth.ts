import { account, ID } from './appwrite';

export async function signUp(email: string, password: string, name: string) {
  const user = await account.create(ID.unique(), email, password, name);
  await account.createEmailPasswordSession(email, password);
  return user;
}

export async function signIn(email: string, password: string) {
  try {
    await account.deleteSession('current');
  } catch {
    // Ignore error if no session exists
  }
  return await account.createEmailPasswordSession(email, password);
}

export async function signOut() {
  return await account.deleteSession('current');
}

export async function getCurrentUser() {
  try {
    return await account.get();
  } catch {
    return null;
  }
}
