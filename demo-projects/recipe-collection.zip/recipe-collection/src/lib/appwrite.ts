import { Client, Databases, Account, Storage } from 'appwrite';

const client = new Client()
  .setEndpoint(process.env.NEXT_PUBLIC_APPWRITE_ENDPOINT || 'https://cloud.appwrite.io/v1')
  .setProject(process.env.NEXT_PUBLIC_APPWRITE_PROJECT_ID!);

export const databases = new Databases(client);
export const account = new Account(client);
export const storage = new Storage(client);
export { ID } from 'appwrite';

export const DATABASE_ID = process.env.NEXT_PUBLIC_DATABASE_ID!;
export const RECIPES_COLLECTION_ID = process.env.NEXT_PUBLIC_RECIPES_COLLECTION_ID!;
export const BUCKET_ID = process.env.NEXT_PUBLIC_BUCKET_ID!;
