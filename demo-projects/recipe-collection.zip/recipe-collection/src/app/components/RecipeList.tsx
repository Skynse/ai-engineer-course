'use client';

import { useState } from 'react';
import { Recipe } from '@/types/recipe';
import RecipeItem from './RecipeItem';

interface RecipeListProps {
  recipes: Recipe[];
  onRecipeUpdated: () => void;
}

export default function RecipeList({ recipes, onRecipeUpdated }: RecipeListProps) {
  const [editingRecipe, setEditingRecipe] = useState<Recipe | null>(null);

  if (recipes.length === 0) {
    return (
      <div className="text-center py-12 text-gray-500">
        No recipes yet. Create your first recipe!
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {recipes.map((recipe) => (
        <RecipeItem
          key={recipe.$id}
          recipe={recipe}
          onRecipeUpdated={onRecipeUpdated}
          isEditing={editingRecipe?.$id === recipe.$id}
          onEdit={() => setEditingRecipe(recipe)}
          onCancelEdit={() => setEditingRecipe(null)}
        />
      ))}
    </div>
  );
}