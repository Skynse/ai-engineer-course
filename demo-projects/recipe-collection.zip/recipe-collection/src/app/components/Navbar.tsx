'use client';

import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { signOut } from '@/lib/auth';
import { useAuth } from './AuthProvider';

type ViewMode = 'collection' | 'community' | 'create';

function SearchIcon() {
  return (
    <svg aria-hidden="true" className="h-4 w-4" fill="none" viewBox="0 0 24 24">
      <circle cx="11" cy="11" r="6.5" stroke="currentColor" strokeWidth="1.8" />
      <path d="m16 16 5 5" stroke="currentColor" strokeLinecap="round" strokeWidth="1.8" />
    </svg>
  );
}

export default function Navbar({
  activeView,
  canCreate,
  onAddRecipe,
  onNavigate,
  search,
  setSearch,
}: {
  activeView: ViewMode;
  canCreate: boolean;
  onAddRecipe: () => void;
  onNavigate: (view: ViewMode) => void;
  search: string;
  setSearch: (value: string) => void;
}) {
  const { user, refreshUser } = useAuth();
  const router = useRouter();

  async function handleSignOut() {
    await signOut();
    await refreshUser();
    router.push('/auth/signin');
  }

  const navItems: Array<{ label: string; view: Exclude<ViewMode, 'create'> }> = [
    { label: 'My Collection', view: 'collection' },
    { label: 'Browse Community', view: 'community' },
  ];

  return (
    <header className="sticky top-0 z-50 border-b border-[#eef1f1] bg-white/80 backdrop-blur-md">
      <nav className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-4 px-3 sm:px-6">
        <div className="flex min-w-0 items-center gap-4 sm:gap-8">
          <Link
            className="shrink-0 text-lg font-black tracking-[-0.04em] text-[#2d3435]"
            href="/"
            onClick={() => onNavigate('collection')}
          >
            The Culinary Ledger
          </Link>

          <div className="hidden items-center gap-6 md:flex">
            {navItems.map((item) => (
              <button
                key={item.view}
                className={`border-b-2 pb-1 text-sm transition ${
                  activeView === item.view
                    ? 'border-[#1b6d24] font-semibold text-[#1b6d24]'
                    : 'border-transparent text-[#7a8081] hover:text-[#2d3435]'
                }`}
                onClick={() => onNavigate(item.view)}
                type="button"
              >
                {item.label}
              </button>
            ))}
          </div>
        </div>

        <div className="flex items-center gap-3 sm:gap-4">
          <label className="hidden items-center gap-2 rounded-md bg-[#f2f4f4] px-3 py-2 text-[#5a6061] sm:flex">
            <SearchIcon />
            <span className="sr-only">Search recipes</span>
            <input
              className="w-40 bg-transparent text-sm text-[#2d3435] outline-none placeholder:text-[#98a0a1] lg:w-52"
              onChange={(event) => setSearch(event.target.value)}
              placeholder={activeView === 'community' ? 'Search community...' : 'Search collection...'}
              type="text"
              value={search}
            />
          </label>

          <button
            className="hidden rounded-md bg-[linear-gradient(145deg,#1b6d24,#076019)] px-4 py-2 text-sm font-medium text-[#e5ffdd] transition active:scale-[0.99] sm:inline-flex"
            onClick={onAddRecipe}
            type="button"
          >
            {canCreate ? '+ Add Recipe' : 'Sign In to Add'}
          </button>

          {user && (
            <>
              <span className="hidden text-sm text-[#5a6061] lg:block">{user.name}</span>
              <button
                className="rounded-md bg-[#e4e9ea] px-3 py-2 text-sm font-medium text-[#2d3435] transition hover:bg-[#dde4e5]"
                onClick={handleSignOut}
                type="button"
              >
                Sign Out
              </button>
            </>
          )}

          {!user && (
            <>
              <Link
                className="hidden text-sm font-medium text-[#5a6061] transition hover:text-[#2d3435] sm:inline-flex"
                href="/auth/signin"
              >
                Sign In
              </Link>
              <Link
                className="rounded-md bg-[#e4e9ea] px-3 py-2 text-sm font-medium text-[#2d3435] transition hover:bg-[#dde4e5]"
                href="/auth/signup"
              >
                Join
              </Link>
            </>
          )}
        </div>
      </nav>

      <div className="border-t border-[#f3f4f4] px-3 py-3 md:hidden">
        <div className="mx-auto flex max-w-7xl items-center gap-3 overflow-x-auto">
          {navItems.map((item) => (
            <button
              key={item.view}
              className={`shrink-0 rounded-md px-3 py-2 text-sm transition ${
                activeView === item.view
                  ? 'bg-[#e4e9ea] font-semibold text-[#1b6d24]'
                  : 'bg-[#f2f4f4] text-[#5a6061]'
              }`}
              onClick={() => onNavigate(item.view)}
              type="button"
            >
              {item.label}
            </button>
          ))}
          <button
            className="shrink-0 rounded-md bg-[linear-gradient(145deg,#1b6d24,#076019)] px-3 py-2 text-sm font-medium text-[#e5ffdd]"
            onClick={onAddRecipe}
            type="button"
          >
            {canCreate ? 'Add Recipe' : 'Sign In to Add'}
          </button>
        </div>
      </div>
    </header>
  );
}
