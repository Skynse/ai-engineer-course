/* eslint-disable @next/next/no-img-element */
'use client';

import { useState } from 'react';
import { Recipe, CATEGORIES } from '@/types/recipe';
import { storage, BUCKET_ID } from '@/lib/appwrite';

interface RecipeItemProps {
  recipe: Recipe;
  onRecipeUpdated: () => void;
  isEditing: boolean;
  onEdit: () => void;
  onCancelEdit: () => void;
}

function getImageUrl(imageId: string) {
  return `${process.env.NEXT_PUBLIC_APPWRITE_ENDPOINT}/storage/buckets/${BUCKET_ID}/files/${imageId}/view?project=${process.env.NEXT_PUBLIC_APPWRITE_PROJECT_ID}`;
}

export default function RecipeItem({
  recipe,
  onRecipeUpdated,
  isEditing,
  onEdit,
  onCancelEdit,
}: RecipeItemProps) {
  const [isDeleting, setIsDeleting] = useState(false);
  const [editedRecipe, setEditedRecipe] = useState(recipe);
  const [imagePreview, setImagePreview] = useState<string | null>(recipe.imageId ? getImageUrl(recipe.imageId) : null);
  const [newImage, setNewImage] = useState<File | null>(null);

  const handleDelete = async () => {
    if (!confirm('Are you sure you want to delete this recipe?')) return;

    setIsDeleting(true);
    try {
      const res = await fetch(`/api/recipes/${recipe.$id}`, { method: 'DELETE' });
      if (res.ok) {
        onRecipeUpdated();
      }
    } catch (error) {
      console.error('Error deleting recipe:', error);
    }
    setIsDeleting(false);
  };

  const handleUpdate = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      let imageId = recipe.imageId;

      if (newImage) {
        const uploadedFile = await storage.createFile(BUCKET_ID, 'unique()', newImage);
        imageId = uploadedFile.$id;
      }

      const res = await fetch(`/api/recipes/${recipe.$id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...editedRecipe, imageId }),
      });

      if (res.ok) {
        onRecipeUpdated();
        onCancelEdit();
      }
    } catch (error) {
      console.error('Error updating recipe:', error);
    }
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setNewImage(file);
      setImagePreview(URL.createObjectURL(file));
    }
  };

  if (isEditing) {
    return (
      <form onSubmit={handleUpdate} className="rounded-[1.75rem] border border-[#ecdcc7] bg-white p-6 shadow-[0_18px_45px_rgba(139,69,19,0.08)]">
        <div className="space-y-4">
          <input
            type="text"
            value={editedRecipe.title}
            onChange={(e) => setEditedRecipe({ ...editedRecipe, title: e.target.value })}
            className="w-full rounded-2xl border border-[#e8dccc] px-4 py-3"
            placeholder="Recipe title"
            required
          />

          <textarea
            value={editedRecipe.description}
            onChange={(e) => setEditedRecipe({ ...editedRecipe, description: e.target.value })}
            className="w-full rounded-2xl border border-[#e8dccc] px-4 py-3"
            placeholder="Description"
            rows={2}
          />

          <select
            value={editedRecipe.category}
            onChange={(e) => setEditedRecipe({ ...editedRecipe, category: e.target.value })}
            className="w-full rounded-2xl border border-[#e8dccc] px-4 py-3"
          >
            {CATEGORIES.map((cat) => (
              <option key={cat} value={cat}>{cat}</option>
            ))}
          </select>

          <div className="flex gap-4">
            <input
              type="number"
              value={editedRecipe.cookingTime}
              onChange={(e) => setEditedRecipe({ ...editedRecipe, cookingTime: Number(e.target.value) || 0 })}
              className="w-1/2 rounded-2xl border border-[#e8dccc] px-4 py-3"
              placeholder="Cooking time (min)"
              min="1"
            />
            <input
              type="number"
              value={editedRecipe.servings}
              onChange={(e) => setEditedRecipe({ ...editedRecipe, servings: Number(e.target.value) || 0 })}
              className="w-1/2 rounded-2xl border border-[#e8dccc] px-4 py-3"
              placeholder="Servings"
              min="1"
            />
          </div>

          <div>
            {imagePreview && (
              <img
                src={imagePreview}
                alt="Recipe preview"
                className="mb-2 h-40 w-full rounded-2xl object-cover"
              />
            )}
            <input
              type="file"
              accept="image/*"
              onChange={handleImageChange}
              className="w-full"
            />
          </div>

          <div className="flex gap-2">
            <button type="submit" className="flex-1 rounded-full bg-[#8b4513] py-3 text-white hover:bg-[#6f350c]">Save</button>
            <button type="button" onClick={onCancelEdit} className="flex-1 rounded-full bg-[#f3e7d6] py-3 text-[#6e4a2f] hover:bg-[#eadac3]">Cancel</button>
          </div>
        </div>
      </form>
    );
  }

  return (
    <div className="overflow-hidden rounded-[1.75rem] border border-[#ecdcc7] bg-white shadow-[0_18px_45px_rgba(139,69,19,0.08)]">
      {recipe.imageId && (
        <img
          src={getImageUrl(recipe.imageId)}
          alt={recipe.title}
          className="h-48 w-full object-cover"
        />
      )}

      <div className="p-6">
        <div className="mb-2 flex justify-between gap-3">
          <span className="inline-block rounded-full bg-[#fff1df] px-3 py-1 text-xs font-bold uppercase tracking-[0.18em] text-[#b86200]">
            {recipe.category}
          </span>
          <span className="text-sm text-[#8a6240]">
            {recipe.cookingTime} min • {recipe.servings} servings
          </span>
        </div>

        <h3 className="text-xl font-semibold text-[#45220d]">{recipe.title}</h3>
        <p className="mb-4 mt-2 text-sm leading-6 text-[#7c5532]">{recipe.description}</p>

        <div className="mb-4">
          <h4 className="mb-2 font-semibold text-[#5d3818]">Ingredients</h4>
          <ul className="list-disc list-inside text-sm text-[#7c5532]">
            {recipe.ingredients.map((ingredient, idx) => (
              <li key={idx}>{ingredient}</li>
            ))}
          </ul>
        </div>

        <div className="mb-4">
          <h4 className="mb-2 font-semibold text-[#5d3818]">Instructions</h4>
          <ol className="list-decimal list-inside text-sm text-[#7c5532]">
            {recipe.instructions.map((instruction, idx) => (
              <li key={idx}>{instruction}</li>
            ))}
          </ol>
        </div>

        <div className="flex gap-2">
          <button onClick={onEdit} className="flex-1 rounded-full bg-[#d97706] py-3 text-white hover:bg-[#b86200]">Edit</button>
          <button
            onClick={handleDelete}
            disabled={isDeleting}
            className="flex-1 rounded-full bg-red-50 py-3 text-red-700 hover:bg-red-100 disabled:opacity-50"
          >
            {isDeleting ? 'Deleting...' : 'Delete'}
          </button>
        </div>
      </div>
    </div>
  );
}
