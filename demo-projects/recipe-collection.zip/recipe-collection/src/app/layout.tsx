import type { Metadata } from 'next';
import './globals.css';
import { AuthProvider } from './components/AuthProvider';

export const metadata: Metadata = {
  title: 'The Culinary Ledger',
  description: 'Create recipes, keep your own collection, and browse the community ledger.',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="min-h-full bg-[#f9f9f9] antialiased">
        <AuthProvider>{children}</AuthProvider>
      </body>
    </html>
  );
}
