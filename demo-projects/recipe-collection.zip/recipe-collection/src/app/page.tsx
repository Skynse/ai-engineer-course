"use client";
/* eslint-disable @next/next/no-img-element */

import {
  ChangeEvent,
  FormEvent,
  useCallback,
  useEffect,
  useMemo,
  useState,
} from "react";
import { Models, Query } from "appwrite";
import { useRouter } from "next/navigation";
import Navbar from "./components/Navbar";
import { useAuth } from "./components/AuthProvider";
import {
  BUCKET_ID,
  DATABASE_ID,
  databases,
  ID,
  RECIPES_COLLECTION_ID,
  storage,
} from "@/lib/appwrite";

type ViewMode = "collection" | "community" | "create";

type IngredientInput = {
  id: string;
  amount: string;
  item: string;
};

interface Recipe {
  $id: string;
  title: string;
  description: string;
  ingredients: string[];
  instructions: string[];
  category: string;
  cookingTime: number;
  servings: number;
  imageId: string | null;
  userId: string;
  userName: string;
  $createdAt: string;
}

const CATEGORY_OPTIONS = [
  "Breakfast",
  "Lunch",
  "Dinner",
  "Dessert",
  "Snack",
  "Beverage",
  "Other",
] as const;
const COLLECTION_FILTERS = ["All Recipes", "Favorites"] as const;
const FAVORITES_STORAGE_KEY = "culinary-ledger-favorites";

function normalizeRecipe(document: Models.Document): Recipe {
  return {
    $id: document.$id,
    title: String(document.title ?? ""),
    description: String(document.description ?? ""),
    ingredients: Array.isArray(document.ingredients)
      ? document.ingredients.map((value: unknown) => String(value))
      : [],
    instructions: Array.isArray(document.instructions)
      ? document.instructions.map((value: unknown) => String(value))
      : [],
    category: String(document.category ?? "Other"),
    cookingTime: Number(document.cookingTime ?? 0),
    servings: Number(document.servings ?? 1),
    imageId: document.imageId ? String(document.imageId) : null,
    userId: String(document.userId ?? ""),
    userName: String(document.userName ?? "Anonymous"),
    $createdAt: String(document.$createdAt ?? ""),
  };
}

function createIngredientRow(): IngredientInput {
  return {
    id: ID.unique(),
    amount: "",
    item: "",
  };
}

function createInstructionRow() {
  return {
    id: ID.unique(),
    text: "",
  };
}

function formatRecipeDate(dateString: string) {
  return new Intl.DateTimeFormat("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
  }).format(new Date(dateString));
}

function getImageUrl(imageId: string) {
  return `${process.env.NEXT_PUBLIC_APPWRITE_ENDPOINT}/storage/buckets/${BUCKET_ID}/files/${imageId}/view?project=${process.env.NEXT_PUBLIC_APPWRITE_PROJECT_ID}`;
}

function cardTone(index: number) {
  const tones = [
    "from-[#dbe7dc] via-[#eef3ee] to-[#ffffff]",
    "from-[#ece6dc] via-[#f8f4ed] to-[#ffffff]",
    "from-[#e2eaec] via-[#f3f7f7] to-[#ffffff]",
    "from-[#f0eadf] via-[#fbf9f4] to-[#ffffff]",
  ];

  return tones[index % tones.length];
}

function RecipeArtwork({
  recipe,
  className,
  priority = false,
  toneIndex = 0,
}: {
  recipe: Recipe;
  className: string;
  priority?: boolean;
  toneIndex?: number;
}) {
  if (recipe.imageId) {
    return (
      <img
        alt={recipe.title}
        className={className}
        loading={priority ? "eager" : "lazy"}
        src={getImageUrl(recipe.imageId)}
      />
    );
  }

  return (
    <div
      className={`${className} bg-gradient-to-br ${cardTone(toneIndex)} text-[#2d3435]`}
    >
      <div className="flex h-full flex-col justify-between p-6">
        <span className="text-[0.65rem] font-semibold uppercase tracking-[0.28em] text-[#5a6061]">
          {recipe.category}
        </span>
        <div>
          <div className="max-w-[12rem] text-3xl font-black tracking-[-0.04em] text-[#2d3435]">
            {recipe.title}
          </div>
          <p className="mt-3 max-w-[14rem] text-sm leading-6 text-[#5a6061]">
            {recipe.description}
          </p>
        </div>
      </div>
    </div>
  );
}

function SearchIcon() {
  return (
    <svg aria-hidden="true" className="h-4 w-4" fill="none" viewBox="0 0 24 24">
      <circle cx="11" cy="11" r="6.5" stroke="currentColor" strokeWidth="1.8" />
      <path
        d="m16 16 5 5"
        stroke="currentColor"
        strokeLinecap="round"
        strokeWidth="1.8"
      />
    </svg>
  );
}

function GridIcon() {
  return (
    <svg
      aria-hidden="true"
      className="h-4 w-4"
      fill="currentColor"
      viewBox="0 0 24 24"
    >
      <path d="M4 4h6v6H4zM14 4h6v6h-6zM4 14h6v6H4zM14 14h6v6h-6z" />
    </svg>
  );
}

function HeartIcon({ filled = false }: { filled?: boolean }) {
  return (
    <svg
      aria-hidden="true"
      className="h-4 w-4"
      fill={filled ? "currentColor" : "none"}
      viewBox="0 0 24 24"
    >
      <path
        d="M12 20.5 4.8 13.7a4.9 4.9 0 0 1 6.9-7l.3.3.3-.3a4.9 4.9 0 1 1 6.9 7L12 20.5Z"
        stroke="currentColor"
        strokeWidth="1.8"
      />
    </svg>
  );
}

function ClockIcon() {
  return (
    <svg aria-hidden="true" className="h-4 w-4" fill="none" viewBox="0 0 24 24">
      <circle cx="12" cy="12" r="8" stroke="currentColor" strokeWidth="1.8" />
      <path
        d="M12 7v5l3 2"
        stroke="currentColor"
        strokeLinecap="round"
        strokeWidth="1.8"
      />
    </svg>
  );
}

function ForkIcon() {
  return (
    <svg aria-hidden="true" className="h-4 w-4" fill="none" viewBox="0 0 24 24">
      <path
        d="M7 3v7M10 3v7M7 7h3M8.5 10v11M16 3v8a3 3 0 0 1-3 3h0v7"
        stroke="currentColor"
        strokeLinecap="round"
        strokeWidth="1.8"
      />
    </svg>
  );
}

function PlusIcon() {
  return (
    <svg aria-hidden="true" className="h-4 w-4" fill="none" viewBox="0 0 24 24">
      <path
        d="M12 5v14M5 12h14"
        stroke="currentColor"
        strokeLinecap="round"
        strokeWidth="1.8"
      />
    </svg>
  );
}

function CloseIcon() {
  return (
    <svg aria-hidden="true" className="h-4 w-4" fill="none" viewBox="0 0 24 24">
      <path
        d="m6 6 12 12M18 6 6 18"
        stroke="currentColor"
        strokeLinecap="round"
        strokeWidth="1.8"
      />
    </svg>
  );
}

function isKeyboardOpenKey(key: string) {
  return key === "Enter" || key === " ";
}

export default function Home() {
  const { user, loading: authLoading } = useAuth();
  const router = useRouter();
  const [recipes, setRecipes] = useState<Recipe[]>([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [viewMode, setViewMode] = useState<ViewMode>("community");
  const [search, setSearch] = useState("");
  const [collectionFilter, setCollectionFilter] =
    useState<(typeof COLLECTION_FILTERS)[number]>("All Recipes");
  const [categoryFilter, setCategoryFilter] = useState<string>("All");
  const [selectedRecipe, setSelectedRecipe] = useState<Recipe | null>(null);
  const [formError, setFormError] = useState("");
  const [favorites, setFavorites] = useState<string[]>([]);
  const [deleteError, setDeleteError] = useState("");
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] =
    useState<(typeof CATEGORY_OPTIONS)[number]>("Dinner");
  const [cookingTime, setCookingTime] = useState("45");
  const [servings, setServings] = useState("4");
  const [ingredients, setIngredients] = useState<IngredientInput[]>([
    createIngredientRow(),
    createIngredientRow(),
    createIngredientRow(),
  ]);
  const [instructions, setInstructions] = useState([
    { ...createInstructionRow(), text: "" },
    { ...createInstructionRow(), text: "" },
  ]);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);

  const loadRecipes = useCallback(async () => {
    setLoading(true);

    try {
      const response = await databases.listDocuments(
        DATABASE_ID,
        RECIPES_COLLECTION_ID,
        [Query.orderDesc("$createdAt"), Query.limit(100)],
      );

      setRecipes(response.documents.map(normalizeRecipe));
    } catch (error) {
      console.error("Error loading recipes:", error);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (!authLoading) {
      void loadRecipes();
    }
  }, [authLoading, loadRecipes]);

  useEffect(() => {
    if (!authLoading) {
      setViewMode(user ? "collection" : "community");
    }
  }, [authLoading, user]);

  useEffect(() => {
    if (typeof window === "undefined") {
      return;
    }

    const storedFavorites = window.localStorage.getItem(FAVORITES_STORAGE_KEY);
    if (storedFavorites) {
      try {
        const parsedFavorites = JSON.parse(storedFavorites);
        if (Array.isArray(parsedFavorites)) {
          setFavorites(
            parsedFavorites.filter(
              (value): value is string => typeof value === "string",
            ),
          );
        }
      } catch {
        window.localStorage.removeItem(FAVORITES_STORAGE_KEY);
      }
    }
  }, []);

  useEffect(() => {
    return () => {
      if (imagePreview) {
        URL.revokeObjectURL(imagePreview);
      }
    };
  }, [imagePreview]);

  const totalCookTime = useMemo(
    () => recipes.reduce((sum, recipe) => sum + recipe.cookingTime, 0),
    [recipes],
  );

  const allCategories = useMemo(() => {
    const categorySet = new Set(
      recipes.map((recipe) => recipe.category).filter(Boolean),
    );
    return ["All", ...Array.from(categorySet)];
  }, [recipes]);

  const myRecipes = useMemo(
    () => recipes.filter((recipe) => recipe.userId === user?.$id),
    [recipes, user?.$id],
  );

  const communityRecipes = useMemo(
    () => recipes.filter((recipe) => !user || recipe.userId !== user.$id),
    [recipes, user],
  );

  const searchedRecipes = useCallback(
    (sourceRecipes: Recipe[]) => {
      const searchTerm = search.trim().toLowerCase();

      return sourceRecipes.filter((recipe) => {
        const matchesSearch =
          !searchTerm ||
          recipe.title.toLowerCase().includes(searchTerm) ||
          recipe.description.toLowerCase().includes(searchTerm) ||
          recipe.category.toLowerCase().includes(searchTerm) ||
          recipe.userName.toLowerCase().includes(searchTerm) ||
          recipe.ingredients.some((ingredient) =>
            ingredient.toLowerCase().includes(searchTerm),
          ) ||
          recipe.instructions.some((instruction) =>
            instruction.toLowerCase().includes(searchTerm),
          );

        const matchesCategory =
          categoryFilter === "All" || recipe.category === categoryFilter;

        return matchesSearch && matchesCategory;
      });
    },
    [categoryFilter, search],
  );

  const favoriteSet = useMemo(() => new Set(favorites), [favorites]);

  const filteredMyRecipes = useMemo(() => {
    const searched = searchedRecipes(myRecipes);
    if (collectionFilter === "Favorites") {
      return searched.filter((recipe) => favoriteSet.has(recipe.$id));
    }
    return searched;
  }, [collectionFilter, favoriteSet, myRecipes, searchedRecipes]);
  const filteredCommunityRecipes = useMemo(
    () => searchedRecipes(communityRecipes),
    [communityRecipes, searchedRecipes],
  );

  const featuredRecipe = filteredCommunityRecipes[0] ?? null;
  const spotlightRecipes = filteredCommunityRecipes.slice(
    featuredRecipe ? 1 : 0,
    featuredRecipe ? 4 : 3,
  );

  function resetForm() {
    setTitle("");
    setDescription("");
    setCategory("Dinner");
    setCookingTime("45");
    setServings("4");
    setIngredients([
      createIngredientRow(),
      createIngredientRow(),
      createIngredientRow(),
    ]);
    setInstructions([
      { ...createInstructionRow(), text: "" },
      { ...createInstructionRow(), text: "" },
    ]);
    setImageFile(null);
    if (imagePreview) {
      URL.revokeObjectURL(imagePreview);
    }
    setImagePreview(null);
    setFormError("");
  }

  function persistFavorites(nextFavorites: string[]) {
    setFavorites(nextFavorites);
    if (typeof window !== "undefined") {
      window.localStorage.setItem(
        FAVORITES_STORAGE_KEY,
        JSON.stringify(nextFavorites),
      );
    }
  }

  function toggleFavorite(recipeId: string) {
    const nextFavorites = favoriteSet.has(recipeId)
      ? favorites.filter((id) => id !== recipeId)
      : [...favorites, recipeId];

    persistFavorites(nextFavorites);
  }

  function updateIngredient(
    id: string,
    field: "amount" | "item",
    value: string,
  ) {
    setIngredients((current) =>
      current.map((ingredient) =>
        ingredient.id === id ? { ...ingredient, [field]: value } : ingredient,
      ),
    );
  }

  function removeIngredient(id: string) {
    setIngredients((current) =>
      current.length > 1
        ? current.filter((ingredient) => ingredient.id !== id)
        : current,
    );
  }

  function updateInstruction(id: string, value: string) {
    setInstructions((current) =>
      current.map((instruction) =>
        instruction.id === id ? { ...instruction, text: value } : instruction,
      ),
    );
  }

  function removeInstruction(id: string) {
    setInstructions((current) =>
      current.length > 1
        ? current.filter((instruction) => instruction.id !== id)
        : current,
    );
  }

  function handleImageChange(event: ChangeEvent<HTMLInputElement>) {
    const nextFile = event.target.files?.[0] ?? null;

    if (imagePreview) {
      URL.revokeObjectURL(imagePreview);
    }

    setImageFile(nextFile);
    setImagePreview(nextFile ? URL.createObjectURL(nextFile) : null);
  }

  async function handleDeleteRecipe(recipe: Recipe) {
    if (!user || recipe.userId !== user.$id || recipe.$id === "draft-preview") {
      return;
    }

    const confirmed = window.confirm(
      `Delete "${recipe.title}" from your collection?`,
    );
    if (!confirmed) {
      return;
    }

    setDeleteError("");

    try {
      await databases.deleteDocument(
        DATABASE_ID,
        RECIPES_COLLECTION_ID,
        recipe.$id,
      );

      if (recipe.imageId) {
        try {
          await storage.deleteFile(BUCKET_ID, recipe.imageId);
        } catch (error) {
          console.error("Error deleting recipe image:", error);
        }
      }

      const nextFavorites = favorites.filter((id) => id !== recipe.$id);
      persistFavorites(nextFavorites);
      setSelectedRecipe((current) =>
        current?.$id === recipe.$id ? null : current,
      );
      await loadRecipes();
    } catch (error) {
      console.error("Error deleting recipe:", error);
      setDeleteError(
        error instanceof Error
          ? error.message
          : "Unable to delete this recipe.",
      );
    }
  }

  async function handleCreateRecipe(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    if (!user) {
      setFormError("Sign in to add recipes to the ledger.");
      return;
    }

    const cleanIngredients = ingredients
      .map((ingredient) =>
        [ingredient.amount.trim(), ingredient.item.trim()]
          .filter(Boolean)
          .join(" "),
      )
      .filter(Boolean);

    const cleanInstructions = instructions
      .map((instruction) => instruction.text.trim())
      .filter(Boolean);

    if (
      !title.trim() ||
      !description.trim() ||
      cleanIngredients.length === 0 ||
      cleanInstructions.length === 0
    ) {
      setFormError(
        "Add a title, a description, at least one ingredient, and at least one execution step.",
      );
      return;
    }

    setSubmitting(true);
    setFormError("");

    try {
      let imageId: string | null = null;

      if (imageFile) {
        const uploaded = await storage.createFile(
          BUCKET_ID,
          ID.unique(),
          imageFile,
        );
        imageId = uploaded.$id;
      }

      await databases.createDocument(
        DATABASE_ID,
        RECIPES_COLLECTION_ID,
        ID.unique(),
        {
          title: title.trim(),
          description: description.trim(),
          ingredients: cleanIngredients,
          instructions: cleanInstructions,
          cookingTime: Number(cookingTime) || 0,
          servings: Number(servings) || 1,
          category,
          imageId,
          userId: user.$id,
          userName: user.name || "Anonymous",
        },
      );

      await loadRecipes();
      resetForm();
      setViewMode("collection");
    } catch (error) {
      console.error("Error creating recipe:", error);
      setFormError(
        error instanceof Error
          ? error.message
          : "Unable to save this ledger entry.",
      );
    } finally {
      setSubmitting(false);
    }
  }

  if (authLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-[#f9f9f9] text-sm text-[#5a6061]">
        Loading the ledger...
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#f9f9f9] text-[#2d3435]">
      <Navbar
        activeView={viewMode}
        canCreate={Boolean(user)}
        onAddRecipe={() => {
          if (user) {
            setViewMode("create");
          } else {
            router.push("/auth/signin");
          }
        }}
        onNavigate={setViewMode}
        search={search}
        setSearch={setSearch}
      />

      <main className="mx-auto max-w-7xl px-3 pb-16 pt-10 sm:px-6 sm:pt-12">
        {viewMode === "collection" && (
          <section className="flex gap-12">
            <aside className="hidden w-64 shrink-0 lg:block">
              <div className="sticky top-28 space-y-8">
                <section>
                  <h3 className="mb-4 text-[0.72rem] font-bold uppercase tracking-[0.26em] text-[#5a6061]">
                    Navigation
                  </h3>
                  <ul className="space-y-1">
                    {COLLECTION_FILTERS.map((filter) => (
                      <li key={filter}>
                        <button
                          className={`flex w-full items-center gap-3 rounded-md px-3 py-2 text-left text-sm transition ${
                            collectionFilter === filter
                              ? "bg-[#e4e9ea] font-semibold text-[#1b6d24]"
                              : "text-[#5a6061] hover:bg-[#f2f4f4]"
                          }`}
                          onClick={() => setCollectionFilter(filter)}
                          type="button"
                        >
                          {filter === "All Recipes" && <GridIcon />}
                          {filter === "Favorites" && <HeartIcon filled />}
                          <span>{filter}</span>
                        </button>
                      </li>
                    ))}
                  </ul>
                </section>

                <section>
                  <h3 className="mb-4 text-[0.72rem] font-bold uppercase tracking-[0.26em] text-[#5a6061]">
                    Categories
                  </h3>
                  <div className="flex flex-wrap gap-2">
                    {allCategories.slice(1).map((item) => (
                      <button
                        key={item}
                        className={`rounded-full px-3 py-1 text-xs transition ${
                          categoryFilter === item
                            ? "bg-[#e4e9ea] text-[#1b6d24]"
                            : "bg-[#ebeeef] text-[#5a6061] hover:bg-[#dde4e5]"
                        }`}
                        onClick={() =>
                          setCategoryFilter(
                            categoryFilter === item ? "All" : item,
                          )
                        }
                        type="button"
                      >
                        {item}
                      </button>
                    ))}
                  </div>
                </section>

                <div className="rounded-xl bg-[#dff5dd] p-4 text-sm text-[#065f18]">
                  <p className="font-semibold">Kitchen Insight</p>
                  <p className="mt-2 leading-6">
                    {myRecipes.length === 0
                      ? "Your collection is empty. Start with one complete dish so the demo opens with real content."
                      : `You have ${myRecipes.length} recipe${myRecipes.length === 1 ? "" : "s"} in your collection and ${totalCookTime} total minutes of documented prep.`}
                  </p>
                </div>
              </div>
            </aside>

            <section className="min-w-0 flex-1">
              <header className="mb-12">
                <h1 className="text-4xl font-black tracking-[-0.04em] text-[#2d3435] sm:text-5xl">
                  My Collection
                </h1>
                <p className="mt-3 max-w-2xl text-lg leading-8 text-[#5a6061]">
                  A precision-indexed ledger of your culinary experiments and
                  perfected techniques.
                </p>
              </header>

              {!user ? (
                <div className="rounded-xl bg-white px-8 py-16 text-center text-[#5a6061]">
                  <p className="text-xl font-semibold text-[#2d3435]">
                    Sign in to build your personal collection.
                  </p>
                  <p className="mt-3 text-base leading-7">
                    Community browsing is open. Authentication is only required
                    when you want to save, favorite for your own session, or
                    delete your recipes.
                  </p>
                </div>
              ) : loading ? (
                <div className="rounded-xl bg-white px-6 py-16 text-center text-sm text-[#5a6061]">
                  Loading your saved recipes...
                </div>
              ) : (
                <div className="grid grid-cols-1 gap-8 md:grid-cols-2 xl:grid-cols-3">
                  <button
                    className="group flex aspect-[4/5] flex-col items-center justify-center rounded-xl border-2 border-dashed border-[#d5dada] bg-transparent text-center transition hover:border-[#1b6d24]/40 hover:bg-[#f2f4f4]"
                    onClick={() => setViewMode("create")}
                    type="button"
                  >
                    <span className="flex h-14 w-14 items-center justify-center rounded-full bg-[#e4e9ea] text-[#5a6061] transition group-hover:scale-105 group-hover:bg-[#dff5dd] group-hover:text-[#1b6d24]">
                      <PlusIcon />
                    </span>
                    <span className="mt-6 block text-xl font-bold tracking-[-0.03em] text-[#2d3435]">
                      New Ledger Entry
                    </span>
                    <span className="mt-2 text-sm text-[#5a6061]">
                      Document a new technique
                    </span>
                  </button>

                  {filteredMyRecipes.map((recipe, index) => (
                    <div
                      key={recipe.$id}
                      role="button"
                      tabIndex={0}
                      className="group overflow-hidden rounded-xl bg-white text-left transition hover:shadow-[0_12px_32px_-4px_rgba(45,52,53,0.08)]"
                      onClick={() => setSelectedRecipe(recipe)}
                      onKeyDown={(event) => {
                        if (isKeyboardOpenKey(event.key)) {
                          event.preventDefault();
                          setSelectedRecipe(recipe);
                        }
                      }}
                    >
                      <div className="relative aspect-video overflow-hidden">
                        <RecipeArtwork
                          className="h-full w-full object-cover transition duration-500 group-hover:scale-[1.03]"
                          recipe={recipe}
                          toneIndex={index}
                        />
                        <button
                          aria-label={
                            favoriteSet.has(recipe.$id)
                              ? "Remove from favorites"
                              : "Add to favorites"
                          }
                          className={`absolute right-3 top-3 flex h-8 w-8 items-center justify-center rounded-full shadow-sm backdrop-blur-sm transition ${
                            favoriteSet.has(recipe.$id)
                              ? "bg-white/95 text-[#9e422c]"
                              : "bg-white/85 text-[#7a8081] hover:text-[#9e422c]"
                          }`}
                          onClick={(event) => {
                            event.stopPropagation();
                            toggleFavorite(recipe.$id);
                          }}
                          type="button"
                        >
                          <HeartIcon filled={favoriteSet.has(recipe.$id)} />
                        </button>
                      </div>
                      <div className="p-6">
                        <div className="mb-3 flex items-start justify-between gap-3">
                          <h2 className="text-[1.75rem] font-black leading-9 tracking-[-0.04em] text-[#2d3435]">
                            {recipe.title}
                          </h2>
                          <span className="rounded bg-[#ebeeef] px-2 py-1 text-[0.65rem] font-bold uppercase tracking-[0.24em] text-[#5a6061]">
                            {recipe.category}
                          </span>
                        </div>
                        <div className="flex flex-wrap items-center gap-4 text-xs uppercase tracking-[0.2em] text-[#5a6061]">
                          <span className="flex items-center gap-1.5">
                            <ClockIcon />
                            {recipe.cookingTime} Min
                          </span>
                          <span className="flex items-center gap-1.5">
                            <ForkIcon />
                            {recipe.servings} Servings
                          </span>
                        </div>
                        <div className="mt-5 border-t border-[#eef1f1] pt-4 text-sm text-[#5a6061]">
                          <div className="flex items-center justify-between gap-3">
                            <span className="text-[0.7rem] font-bold uppercase tracking-[0.24em]">
                              Last Saved
                            </span>
                            <span className="font-medium text-[#2d3435]">
                              {formatRecipeDate(recipe.$createdAt)}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}

                  {filteredMyRecipes.length === 0 && (
                    <div className="rounded-xl bg-white px-8 py-16 text-center text-[#5a6061] md:col-span-2 xl:col-span-2">
                      {collectionFilter === "Favorites"
                        ? "No favorited recipes match the current search."
                        : "No recipes match the current filters. Clear search or add a new ledger entry."}
                    </div>
                  )}
                </div>
              )}

              {deleteError && (
                <div className="mt-6 rounded-md bg-[#fff1ee] px-4 py-3 text-sm text-[#9e422c]">
                  {deleteError}
                </div>
              )}
            </section>
          </section>
        )}

        {viewMode === "community" && (
          <section>
            <div className="mb-16 flex flex-col justify-between gap-8 md:flex-row md:items-end">
              <div className="max-w-2xl">
                <span className="mb-4 block text-[0.72rem] font-bold uppercase tracking-[0.28em] text-[#5a6061]">
                  Global Pantry
                </span>
                <h1 className="text-5xl font-black tracking-[-0.05em] text-[#2d3435]">
                  Browse Community
                </h1>
                <p className="mt-4 text-lg font-light leading-8 text-[#5a6061]">
                  Explore precision-crafted recipes shared by other cooks in
                  this Appwrite-backed demo workspace.
                </p>
              </div>

              <div className="flex w-full max-w-md items-center gap-3 text-[#5a6061]">
                <SearchIcon />
                <label className="w-full border-b border-[#d5dada] pb-2">
                  <span className="sr-only">Search community recipes</span>
                  <input
                    className="w-full bg-transparent text-sm text-[#2d3435] outline-none placeholder:text-[#98a0a1]"
                    onChange={(event) => setSearch(event.target.value)}
                    placeholder="Search by ingredient or chef"
                    type="text"
                    value={search}
                  />
                </label>
              </div>
            </div>

            {loading ? (
              <div className="rounded-xl bg-white px-6 py-16 text-center text-sm text-[#5a6061]">
                Loading community recipes...
              </div>
            ) : filteredCommunityRecipes.length === 0 ? (
              <div className="rounded-xl bg-[#ebeeef] px-8 py-16 text-center text-[#5a6061]">
                No community recipes are available yet. Create a second account
                to demonstrate shared browsing.
              </div>
            ) : (
              <>
                <div className="grid grid-cols-1 gap-8 md:grid-cols-12">
                  {featuredRecipe && (
                    <div
                      role="button"
                      tabIndex={0}
                      className="group md:col-span-8"
                      onClick={() => setSelectedRecipe(featuredRecipe)}
                      onKeyDown={(event) => {
                        if (isKeyboardOpenKey(event.key)) {
                          event.preventDefault();
                          setSelectedRecipe(featuredRecipe);
                        }
                      }}
                    >
                      <div className="relative h-[420px] overflow-hidden rounded-xl bg-white shadow-[0_12px_32px_-4px_rgba(45,52,53,0.08)] md:h-[500px]">
                        <RecipeArtwork
                          className="h-full w-full object-cover transition duration-700 group-hover:scale-[1.03]"
                          priority
                          recipe={featuredRecipe}
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/10 to-transparent" />
                        <div className="absolute bottom-0 left-0 p-8 text-white">
                          <span className="rounded bg-[#a3f69c] px-2 py-1 text-[0.62rem] font-bold uppercase tracking-[0.22em] text-[#065f18]">
                            Masterclass
                          </span>
                          <h2 className="mt-4 text-3xl font-black tracking-[-0.04em]">
                            {featuredRecipe.title}
                          </h2>
                          <div className="mt-3 flex flex-wrap items-center gap-3 text-sm font-light">
                            <span>by {featuredRecipe.userName}</span>
                            <span>•</span>
                            <span>{featuredRecipe.cookingTime} Min Prep</span>
                          </div>
                        </div>
                        <button
                          aria-label={
                            favoriteSet.has(featuredRecipe.$id)
                              ? "Remove from favorites"
                              : "Add to favorites"
                          }
                          className={`absolute right-6 top-6 flex h-11 w-11 items-center justify-center rounded-full shadow-lg backdrop-blur-sm transition ${
                            favoriteSet.has(featuredRecipe.$id)
                              ? "bg-white/95 text-[#9e422c]"
                              : "bg-white/90 text-[#1b6d24]"
                          }`}
                          onClick={(event) => {
                            event.stopPropagation();
                            toggleFavorite(featuredRecipe.$id);
                          }}
                          type="button"
                        >
                          <HeartIcon
                            filled={favoriteSet.has(featuredRecipe.$id)}
                          />
                        </button>
                      </div>
                    </div>
                  )}

                  <div className="space-y-6 md:col-span-4">
                    <div className="rounded-xl bg-[#e4e9ea] p-8">
                      <h3 className="mb-6 text-[0.72rem] font-bold uppercase tracking-[0.26em] text-[#5a6061]">
                        Trending Tags
                      </h3>
                      <div className="flex flex-wrap gap-2">
                        {allCategories.slice(1).map((item) => (
                          <button
                            key={item}
                            className={`rounded border px-3 py-1 text-xs font-medium transition ${
                              categoryFilter === item
                                ? "border-[#1b6d24] bg-white text-[#1b6d24]"
                                : "border-[#d5dada] bg-white text-[#2d3435] hover:border-[#1b6d24]"
                            }`}
                            onClick={() =>
                              setCategoryFilter(
                                categoryFilter === item ? "All" : item,
                              )
                            }
                            type="button"
                          >
                            {item}
                          </button>
                        ))}
                      </div>

                      {featuredRecipe && (
                        <div className="mt-12">
                          <h3 className="mb-4 text-[0.72rem] font-bold uppercase tracking-[0.26em] text-[#5a6061]">
                            Chef Spotlight
                          </h3>
                          <button
                            className="flex items-center gap-4 text-left"
                            onClick={() => setSelectedRecipe(featuredRecipe)}
                            type="button"
                          >
                            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-white text-sm font-bold text-[#1b6d24]">
                              {featuredRecipe.userName
                                .slice(0, 2)
                                .toUpperCase()}
                            </div>
                            <div>
                              <p className="text-sm font-bold text-[#2d3435]">
                                {featuredRecipe.userName}
                              </p>
                              <p className="text-xs text-[#5a6061]">
                                {
                                  communityRecipes.filter(
                                    (recipe) =>
                                      recipe.userName ===
                                      featuredRecipe.userName,
                                  ).length
                                }{" "}
                                Shared Formulas
                              </p>
                            </div>
                          </button>
                        </div>
                      )}
                    </div>
                  </div>

                  {spotlightRecipes.map((recipe, index) => (
                    <div
                      key={recipe.$id}
                      role="button"
                      tabIndex={0}
                      className="group text-left md:col-span-4"
                      onClick={() => setSelectedRecipe(recipe)}
                      onKeyDown={(event) => {
                        if (isKeyboardOpenKey(event.key)) {
                          event.preventDefault();
                          setSelectedRecipe(recipe);
                        }
                      }}
                    >
                      <div className="relative mb-4 aspect-[4/5] overflow-hidden rounded-xl bg-white">
                        <RecipeArtwork
                          className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
                          recipe={recipe}
                          toneIndex={index + 1}
                        />
                        <button
                          aria-label={
                            favoriteSet.has(recipe.$id)
                              ? "Remove from favorites"
                              : "Add to favorites"
                          }
                          className={`absolute right-4 top-4 flex h-9 w-9 items-center justify-center rounded bg-white/90 shadow-sm transition ${
                            favoriteSet.has(recipe.$id)
                              ? "text-[#9e422c]"
                              : "text-[#1b6d24]"
                          }`}
                          onClick={(event) => {
                            event.stopPropagation();
                            toggleFavorite(recipe.$id);
                          }}
                          type="button"
                        >
                          <HeartIcon filled={favoriteSet.has(recipe.$id)} />
                        </button>
                      </div>
                      <div className="space-y-1">
                        <div className="flex items-start justify-between gap-3">
                          <h3 className="text-lg font-bold tracking-[-0.03em] text-[#2d3435]">
                            {recipe.title}
                          </h3>
                          <span className="text-xs font-medium text-[#5a6061]">
                            {recipe.servings} servings
                          </span>
                        </div>
                        <p className="text-[0.7rem] font-bold uppercase tracking-[0.24em] text-[#5a6061]">
                          {recipe.cookingTime} Min · {recipe.category}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>

                {filteredCommunityRecipes.length > 4 && (
                  <div className="mt-20 flex justify-center">
                    <button
                      className="bg-[#e4e9ea] px-8 py-3 text-sm font-bold uppercase tracking-[0.22em] text-[#2d3435] transition hover:bg-[#dde4e5]"
                      onClick={() =>
                        setSelectedRecipe(filteredCommunityRecipes[4])
                      }
                      type="button"
                    >
                      View More Shared Ledger Items
                    </button>
                  </div>
                )}
              </>
            )}
          </section>
        )}

        {viewMode === "create" && user && (
          <section className="py-2">
            <div className="mx-auto max-w-3xl">
              <header className="mb-16 pl-0 sm:pl-6">
                <span className="mb-2 block text-[0.72rem] font-medium uppercase tracking-[0.18em] text-[#5a6061]">
                  Drafting New Entry
                </span>
                <h1 className="text-[2.6rem] font-black tracking-[-0.04em] text-[#2d3435]">
                  New Ledger Entry
                </h1>
              </header>

              <form
                className="space-y-16 sm:pl-6 sm:pr-3"
                onSubmit={handleCreateRecipe}
              >
                <section className="space-y-8">
                  <div className="flex flex-col gap-2">
                    <label className="text-[0.72rem] font-bold uppercase tracking-[0.2em] text-[#5a6061]">
                      Recipe Title
                    </label>
                    <input
                      className="ledger-input pb-2 text-2xl font-semibold text-[#2d3435]"
                      onChange={(event) => setTitle(event.target.value)}
                      type="text"
                      value={title}
                    />
                  </div>

                  <div className="grid grid-cols-1 gap-8 md:grid-cols-2">
                    <div className="flex flex-col gap-2">
                      <label className="text-[0.72rem] font-bold uppercase tracking-[0.2em] text-[#5a6061]">
                        Category
                      </label>
                      <select
                        className="ledger-input pb-2 text-lg text-[#2d3435]"
                        onChange={(event) =>
                          setCategory(
                            event.target
                              .value as (typeof CATEGORY_OPTIONS)[number],
                          )
                        }
                        value={category}
                      >
                        {CATEGORY_OPTIONS.map((option) => (
                          <option key={option} value={option}>
                            {option}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="flex flex-col gap-2">
                      <label className="text-[0.72rem] font-bold uppercase tracking-[0.2em] text-[#5a6061]">
                        Estimated Prep Time
                      </label>
                      <input
                        className="ledger-input pb-2 text-lg text-[#2d3435]"
                        inputMode="numeric"
                        onChange={(event) => setCookingTime(event.target.value)}
                        type="number"
                        value={cookingTime}
                      />
                    </div>

                    <div className="flex flex-col gap-2">
                      <label className="text-[0.72rem] font-bold uppercase tracking-[0.2em] text-[#5a6061]">
                        Servings
                      </label>
                      <input
                        className="ledger-input pb-2 text-lg text-[#2d3435]"
                        inputMode="numeric"
                        onChange={(event) => setServings(event.target.value)}
                        type="number"
                        value={servings}
                      />
                    </div>

                    <div className="flex flex-col gap-2">
                      <label className="text-[0.72rem] font-bold uppercase tracking-[0.2em] text-[#5a6061]">
                        Cover Image
                      </label>
                      <input
                        accept="image/*"
                        className="ledger-input pb-2 text-sm text-[#5a6061] file:mr-4 file:border-0 file:bg-[#e4e9ea] file:px-3 file:py-2 file:text-sm file:font-medium file:text-[#2d3435]"
                        onChange={handleImageChange}
                        type="file"
                      />
                    </div>
                  </div>

                  <div className="flex flex-col gap-2">
                    <label className="text-[0.72rem] font-bold uppercase tracking-[0.2em] text-[#5a6061]">
                      Description
                    </label>
                    <textarea
                      className="ledger-input min-h-28 resize-none pb-2 text-base leading-7 text-[#2d3435]"
                      onChange={(event) => setDescription(event.target.value)}
                      value={description}
                    />
                  </div>

                  {imagePreview && (
                    <div className="overflow-hidden rounded-xl bg-white shadow-[0_12px_32px_-4px_rgba(45,52,53,0.08)]">
                      <img
                        alt="Recipe preview"
                        className="h-64 w-full object-cover"
                        src={imagePreview}
                      />
                    </div>
                  )}
                </section>

                <section className="rounded-lg bg-[#f2f4f4] p-8">
                  <div className="mb-8 flex items-end justify-between gap-4">
                    <div>
                      <h2 className="text-xl font-bold tracking-[-0.03em] text-[#2d3435]">
                        Ingredients
                      </h2>
                      <p className="mt-1 text-sm text-[#5a6061]">
                        List every ingredient and measurement that belongs in
                        this entry.
                      </p>
                    </div>
                    <button
                      className="flex items-center gap-2 text-sm font-semibold text-[#1b6d24] transition hover:opacity-80"
                      onClick={() =>
                        setIngredients((current) => [
                          ...current,
                          createIngredientRow(),
                        ])
                      }
                      type="button"
                    >
                      <PlusIcon />
                      Add Item
                    </button>
                  </div>

                  <div className="overflow-hidden rounded-md border border-[#e7eded] bg-white">
                    {ingredients.map((ingredient, index) => (
                      <div
                        key={ingredient.id}
                        className={`group grid grid-cols-[6rem_minmax(0,1fr)_2rem] items-center gap-4 px-4 py-4 ${
                          index % 2 === 1 ? "bg-[#ebeeef]" : "bg-white"
                        }`}
                      >
                        <input
                          className="bg-transparent text-sm font-medium text-[#2d3435] outline-none"
                          onChange={(event) =>
                            updateIngredient(
                              ingredient.id,
                              "amount",
                              event.target.value,
                            )
                          }
                          placeholder="Qty"
                          type="text"
                          value={ingredient.amount}
                        />
                        <input
                          className="bg-transparent text-sm text-[#2d3435] outline-none"
                          onChange={(event) =>
                            updateIngredient(
                              ingredient.id,
                              "item",
                              event.target.value,
                            )
                          }
                          placeholder="Ingredient"
                          type="text"
                          value={ingredient.item}
                        />
                        <button
                          className="text-[#98a0a1] opacity-0 transition hover:text-[#9e422c] group-hover:opacity-100"
                          onClick={() => removeIngredient(ingredient.id)}
                          type="button"
                        >
                          <CloseIcon />
                        </button>
                      </div>
                    ))}
                  </div>
                </section>

                <section className="space-y-8">
                  <h2 className="text-xl font-bold tracking-[-0.03em] text-[#2d3435]">
                    Execution Steps
                  </h2>
                  <div className="space-y-6">
                    {instructions.map((instruction, index) => (
                      <div
                        key={instruction.id}
                        className={
                          index === 0
                            ? "bg-white p-6 shadow-[0_12px_32px_-4px_rgba(45,52,53,0.08)]"
                            : "rounded-md bg-[#f2f4f4] p-6"
                        }
                      >
                        <div
                          className={
                            index === 0
                              ? "border-l-4 border-[#1b6d24] pl-4"
                              : ""
                          }
                        >
                          <div className="mb-3 flex items-center justify-between gap-4">
                            <span
                              className={`text-[0.7rem] font-bold uppercase tracking-[0.24em] ${index === 0 ? "text-[#1b6d24]" : "text-[#5a6061]"}`}
                            >
                              Step {String(index + 1).padStart(2, "0")}
                            </span>
                            {instructions.length > 1 && (
                              <button
                                className="text-[#98a0a1] transition hover:text-[#9e422c]"
                                onClick={() =>
                                  removeInstruction(instruction.id)
                                }
                                type="button"
                              >
                                <CloseIcon />
                              </button>
                            )}
                          </div>
                          <textarea
                            className={`w-full resize-none bg-transparent text-[#2d3435] outline-none ${
                              index === 0
                                ? "min-h-28 text-lg leading-8"
                                : "min-h-20 text-base leading-7"
                            }`}
                            onChange={(event) =>
                              updateInstruction(
                                instruction.id,
                                event.target.value,
                              )
                            }
                            value={instruction.text}
                          />
                        </div>
                      </div>
                    ))}
                  </div>

                  <button
                    className="flex w-full items-center justify-center gap-2 border-2 border-dashed border-[#d5dada] py-4 text-sm font-medium text-[#5a6061] transition hover:border-[#1b6d24]/40 hover:text-[#1b6d24]"
                    onClick={() =>
                      setInstructions((current) => [
                        ...current,
                        createInstructionRow(),
                      ])
                    }
                    type="button"
                  >
                    <PlusIcon />
                    Append Execution Step
                  </button>
                </section>

                {formError && (
                  <div className="rounded-md bg-[#fff1ee] px-4 py-3 text-sm text-[#9e422c]">
                    {formError}
                  </div>
                )}

                <div className="flex flex-col items-center justify-between gap-4 border-t border-[#e3e8e8] pt-12 md:flex-row">
                  <button
                    className="px-6 py-3 text-sm font-medium text-[#5a6061] transition hover:text-[#2d3435]"
                    onClick={() => {
                      resetForm();
                      setViewMode("collection");
                    }}
                    type="button"
                  >
                    Discard Draft
                  </button>

                  <div className="flex w-full gap-4 md:w-auto">
                    <button
                      className="flex-1 bg-[#e4e9ea] px-8 py-3 text-sm font-medium text-[#2d3435] transition hover:bg-[#dde4e5] md:flex-none"
                      onClick={() => {
                        const previewRecipe: Recipe = {
                          $id: "draft-preview",
                          title: title.trim() || "Untitled Ledger Entry",
                          description:
                            description.trim() ||
                            "Add a short description to preview the final card and detail sheet.",
                          ingredients: ingredients
                            .map((ingredient) =>
                              [ingredient.amount.trim(), ingredient.item.trim()]
                                .filter(Boolean)
                                .join(" "),
                            )
                            .filter(Boolean),
                          instructions: instructions
                            .map((instruction) => instruction.text.trim())
                            .filter(Boolean),
                          category,
                          cookingTime: Number(cookingTime) || 0,
                          servings: Number(servings) || 1,
                          imageId: null,
                          userId: user.$id,
                          userName: user.name || "Anonymous",
                          $createdAt: new Date().toISOString(),
                        };
                        setSelectedRecipe(previewRecipe);
                      }}
                      type="button"
                    >
                      Preview
                    </button>
                    <button
                      className="flex-1 bg-[linear-gradient(145deg,#1b6d24,#076019)] px-10 py-3 text-sm font-bold text-[#e5ffdd] shadow-md transition active:scale-[0.99] disabled:cursor-not-allowed disabled:opacity-60 md:flex-none"
                      disabled={submitting}
                      type="submit"
                    >
                      {submitting ? "Saving..." : "Save to My Collection"}
                    </button>
                  </div>
                </div>
              </form>
            </div>
          </section>
        )}
      </main>

      <footer className="border-t border-[#eef1f1] bg-[#f9f9f9] py-8">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-4 px-6 text-[0.68rem] font-semibold uppercase tracking-[0.22em] text-[#a8b0b1] md:flex-row">
          <p>© 2026 The Culinary Ledger. Precision in every measurement.</p>
          <div className="flex items-center gap-5">
            <span>Privacy</span>
            <span>Terms</span>
            <span>Support</span>
          </div>
        </div>
      </footer>

      {selectedRecipe && (
        <div className="fixed inset-0 z-[70] flex items-start justify-center bg-[#0c0f0f]/45 p-4 backdrop-blur-sm sm:p-8">
          <div className="relative max-h-[90vh] w-full max-w-4xl overflow-y-auto rounded-2xl bg-[#f9f9f9] shadow-[0_24px_64px_rgba(12,15,15,0.16)]">
            <button
              className="absolute right-4 top-4 z-10 flex h-10 w-10 items-center justify-center rounded-full bg-white/90 text-[#5a6061] shadow-sm"
              onClick={() => setSelectedRecipe(null)}
              type="button"
            >
              <CloseIcon />
            </button>

            <div className="grid gap-0 md:grid-cols-[1.1fr_0.9fr]">
              <div className="min-h-[320px] bg-[#ebeeef]">
                {selectedRecipe.$id === "draft-preview" && imagePreview ? (
                  <img
                    alt={selectedRecipe.title}
                    className="h-full w-full object-cover"
                    src={imagePreview}
                  />
                ) : (
                  <RecipeArtwork
                    className="h-full min-h-[320px] w-full object-cover"
                    recipe={selectedRecipe}
                  />
                )}
              </div>

              <div className="p-8">
                <div className="flex items-center justify-between gap-4">
                  <span className="rounded bg-[#ebeeef] px-3 py-1 text-[0.7rem] font-bold uppercase tracking-[0.24em] text-[#5a6061]">
                    {selectedRecipe.category}
                  </span>
                  <div className="flex items-center gap-2">
                    <button
                      aria-label={
                        favoriteSet.has(selectedRecipe.$id)
                          ? "Remove from favorites"
                          : "Add to favorites"
                      }
                      className={`flex h-9 w-9 items-center justify-center rounded-full bg-white transition ${
                        favoriteSet.has(selectedRecipe.$id)
                          ? "text-[#9e422c]"
                          : "text-[#5a6061]"
                      }`}
                      onClick={() => toggleFavorite(selectedRecipe.$id)}
                      type="button"
                    >
                      <HeartIcon filled={favoriteSet.has(selectedRecipe.$id)} />
                    </button>
                    <span className="text-sm text-[#5a6061]">
                      {formatRecipeDate(selectedRecipe.$createdAt)}
                    </span>
                  </div>
                </div>

                <h2 className="mt-5 text-4xl font-black tracking-[-0.05em] text-[#2d3435]">
                  {selectedRecipe.title}
                </h2>
                <p className="mt-4 text-base leading-7 text-[#5a6061]">
                  {selectedRecipe.description}
                </p>

                <div className="mt-6 flex flex-wrap gap-3 text-xs uppercase tracking-[0.22em] text-[#5a6061]">
                  <span className="flex items-center gap-1.5 rounded bg-white px-3 py-2">
                    <ClockIcon />
                    {selectedRecipe.cookingTime} Min
                  </span>
                  <span className="flex items-center gap-1.5 rounded bg-white px-3 py-2">
                    <ForkIcon />
                    {selectedRecipe.servings} Servings
                  </span>
                  <span className="rounded bg-white px-3 py-2">
                    By {selectedRecipe.userName}
                  </span>
                </div>

                {user &&
                  selectedRecipe.userId === user.$id &&
                  selectedRecipe.$id !== "draft-preview" && (
                    <div className="mt-6">
                      <button
                        className="rounded-md bg-[#fff1ee] px-4 py-3 text-sm font-semibold text-[#9e422c] transition hover:bg-[#ffe6e1]"
                        onClick={() => void handleDeleteRecipe(selectedRecipe)}
                        type="button"
                      >
                        Delete Recipe
                      </button>
                    </div>
                  )}

                <section className="mt-10 rounded-xl bg-[#f2f4f4] p-6">
                  <h3 className="text-lg font-bold tracking-[-0.02em] text-[#2d3435]">
                    Ingredients
                  </h3>
                  <ul className="mt-4 space-y-3">
                    {selectedRecipe.ingredients.length === 0 ? (
                      <li className="text-sm text-[#5a6061]">
                        No ingredients listed for this entry.
                      </li>
                    ) : (
                      selectedRecipe.ingredients.map((ingredient, index) => (
                        <li
                          key={`${selectedRecipe.$id}-ingredient-${index}`}
                          className={`rounded px-3 py-3 text-sm text-[#2d3435] ${
                            index % 2 === 1 ? "bg-[#ebeeef]" : "bg-white"
                          }`}
                        >
                          {ingredient}
                        </li>
                      ))
                    )}
                  </ul>
                </section>

                <section className="mt-8">
                  <h3 className="text-lg font-bold tracking-[-0.02em] text-[#2d3435]">
                    Execution Steps
                  </h3>
                  <div className="mt-4 space-y-4">
                    {selectedRecipe.instructions.length === 0 ? (
                      <div className="rounded-md bg-[#ebeeef] px-4 py-4 text-sm text-[#5a6061]">
                        No execution steps listed for this entry.
                      </div>
                    ) : (
                      selectedRecipe.instructions.map((instruction, index) => (
                        <div
                          key={`${selectedRecipe.$id}-instruction-${index}`}
                          className={
                            index === 0
                              ? "bg-white p-5 shadow-[0_12px_32px_-4px_rgba(45,52,53,0.08)]"
                              : "rounded-md bg-[#f2f4f4] p-5"
                          }
                        >
                          <div
                            className={
                              index === 0
                                ? "border-l-4 border-[#1b6d24] pl-4"
                                : ""
                            }
                          >
                            <span
                              className={`block text-[0.7rem] font-bold uppercase tracking-[0.24em] ${index === 0 ? "text-[#1b6d24]" : "text-[#5a6061]"}`}
                            >
                              Step {String(index + 1).padStart(2, "0")}
                            </span>
                            <p className="mt-3 text-base leading-7 text-[#2d3435]">
                              {instruction}
                            </p>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </section>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
