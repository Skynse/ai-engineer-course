'use client';

import { useState } from 'react';
import { signUp } from '@/lib/auth';
import { useAuth } from '@/app/components/AuthProvider';
import Link from 'next/link';
import { useRouter } from 'next/navigation';

function getErrorMessage(error: unknown) {
  return error instanceof Error ? error.message : 'Failed to sign up';
}

export default function SignUp() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const router = useRouter();
  const { refreshUser } = useAuth();

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      await signUp(email, password, name);
      await refreshUser();
      router.push('/');
    } catch (err: unknown) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-[radial-gradient(circle_at_top_right,_rgba(34,197,94,0.14),_transparent_30%),linear-gradient(180deg,_#fff7ed,_#f7ebda)] px-4 py-10">
      <div className="w-full max-w-md rounded-[2rem] border border-[#ecdcc7] bg-[rgba(255,252,247,0.92)] p-8 shadow-[0_30px_80px_rgba(139,69,19,0.12)]">
        <p className="text-sm font-semibold uppercase tracking-[0.34em] text-[#d97706]">Hearth Notes</p>
        <h2 className="mt-4 text-4xl font-black tracking-tight text-[#45220d]">Start your own cookbook.</h2>
        <p className="mt-3 text-sm leading-6 text-[#7c5532]">Create an account to collect dishes, edit ingredients, and keep the course demos useful.</p>

        {error && <div className="mt-6 rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">{error}</div>}

        <form onSubmit={handleSubmit} className="mt-8 space-y-5">
          <div>
            <label className="mb-2 block text-sm font-semibold text-[#5d3818]">Name</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full rounded-2xl border border-[#e8dccc] bg-white px-4 py-3 text-[#45220d] outline-none transition focus:border-[#d97706] focus:ring-4 focus:ring-orange-100"
              placeholder="Julia Child"
              required
            />
          </div>

          <div>
            <label className="mb-2 block text-sm font-semibold text-[#5d3818]">Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full rounded-2xl border border-[#e8dccc] bg-white px-4 py-3 text-[#45220d] outline-none transition focus:border-[#d97706] focus:ring-4 focus:ring-orange-100"
              placeholder="chef@example.com"
              required
            />
          </div>

          <div>
            <label className="mb-2 block text-sm font-semibold text-[#5d3818]">Password</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full rounded-2xl border border-[#e8dccc] bg-white px-4 py-3 text-[#45220d] outline-none transition focus:border-[#d97706] focus:ring-4 focus:ring-orange-100"
              placeholder="At least 8 characters"
              required
              minLength={8}
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full rounded-full bg-[#d97706] px-5 py-3 text-sm font-bold uppercase tracking-[0.22em] text-white transition hover:bg-[#b86200] disabled:opacity-50"
          >
            {loading ? 'Creating Account...' : 'Start Collecting'}
          </button>
        </form>

        <p className="mt-6 text-center text-sm text-[#7c5532]">
          Already have an account?{' '}
          <Link href="/auth/signin" className="font-semibold text-[#8b4513] underline decoration-[#d97706] underline-offset-4">
            Sign in
          </Link>
        </p>
      </div>
    </div>
  );
}
