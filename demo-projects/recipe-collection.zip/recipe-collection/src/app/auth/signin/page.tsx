'use client';

import { useState } from 'react';
import { signIn } from '@/lib/auth';
import { useAuth } from '@/app/components/AuthProvider';
import Link from 'next/link';
import { useRouter } from 'next/navigation';

function getErrorMessage(error: unknown) {
  return error instanceof Error ? error.message : 'Failed to sign in';
}

export default function SignIn() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const router = useRouter();
  const { refreshUser } = useAuth();

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      await signIn(email, password);
      await refreshUser();
      router.push('/');
    } catch (err: unknown) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-[radial-gradient(circle_at_top_left,_rgba(217,119,6,0.18),_transparent_30%),linear-gradient(180deg,_#fff7ed,_#f7ebda)] px-4 py-10">
      <div className="w-full max-w-md rounded-[2rem] border border-[#ecdcc7] bg-[rgba(255,252,247,0.92)] p-8 shadow-[0_30px_80px_rgba(139,69,19,0.12)]">
        <p className="text-sm font-semibold uppercase tracking-[0.34em] text-[#d97706]">Hearth Notes</p>
        <h2 className="mt-4 text-4xl font-black tracking-tight text-[#45220d]">Welcome back to the kitchen.</h2>
        <p className="mt-3 text-sm leading-6 text-[#7c5532]">Sign in to save recipes, collect favorites, and keep your demo looking lived-in.</p>

        {error && <div className="mt-6 rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">{error}</div>}

        <form onSubmit={handleSubmit} className="mt-8 space-y-5">
          <div>
            <label className="mb-2 block text-sm font-semibold text-[#5d3818]">Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full rounded-2xl border border-[#e8dccc] bg-white px-4 py-3 text-[#45220d] outline-none transition focus:border-[#d97706] focus:ring-4 focus:ring-orange-100"
              placeholder="chef@example.com"
              required
            />
          </div>

          <div>
            <label className="mb-2 block text-sm font-semibold text-[#5d3818]">Password</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full rounded-2xl border border-[#e8dccc] bg-white px-4 py-3 text-[#45220d] outline-none transition focus:border-[#d97706] focus:ring-4 focus:ring-orange-100"
              placeholder="••••••••"
              required
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full rounded-full bg-[#8b4513] px-5 py-3 text-sm font-bold uppercase tracking-[0.22em] text-white transition hover:bg-[#6f350c] disabled:opacity-50"
          >
            {loading ? 'Signing In...' : 'Enter Kitchen'}
          </button>
        </form>

        <p className="mt-6 text-center text-sm text-[#7c5532]">
          Don&apos;t have an account?{' '}
          <Link href="/auth/signup" className="font-semibold text-[#8b4513] underline decoration-[#d97706] underline-offset-4">
            Sign up
          </Link>
        </p>
      </div>
    </div>
  );
}
