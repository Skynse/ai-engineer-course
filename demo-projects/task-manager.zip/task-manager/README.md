# Task Manager Demo

A kanban-style task management application built with Next.js and Appwrite.

## Features

- Create tasks with priorities and board status (`Backlog`, `In Progress`, `Done`)
- Manual card ordering inside each column using a LexoRank-style `order` field
- Move cards between columns without losing deterministic ordering
- Edit and delete tasks
- Filter the board by priority
- User authentication
- Responsive board layout

## Setup Instructions

### 1. Appwrite Setup

1. Create an Appwrite Cloud account at https://cloud.appwrite.io
2. Create a new project
3. Create a database named `taskmanager`
4. Create a collection named `tasks` with these attributes:
   - `title` (string, required)
   - `description` (string)
   - `priority` (enum/string: low, medium, high, default: medium)
   - `status` (enum: backlog, in-progress, done, default: backlog)
   - `order` (string, optional)
   - `completed` (boolean, default: false)
   - `userId` (string, required)
   - `userName` (string, required)
   - `completedAt` (string/datetime, optional)

5. Set permissions:
   - Create: `users`
   - Read: `user:{userId}`
   - Update: `user:{userId}`
   - Delete: `user:{userId}`

6. Enable Email/Password authentication in Auth settings

### 2. Environment Variables

Create a `.env.local` file:

```bash
NEXT_PUBLIC_APPWRITE_PROJECT_ID=your_project_id
NEXT_PUBLIC_APPWRITE_ENDPOINT=https://cloud.appwrite.io/v1
NEXT_PUBLIC_DATABASE_ID=taskmanager
NEXT_PUBLIC_TASKS_COLLECTION_ID=tasks
```

### 3. Run the App

```bash
npm install
npm run dev
```

Visit http://localhost:3000

## Notes

- Existing tasks without `status` or `order` are repaired automatically on load.
- The board uses a LexoRank-style ordering key so reordering cards does not require renumbering the full column.
