# Task Manager Demo

A complete task management application built with Next.js and Appwrite.

## Features

- Create tasks with priorities (Low, Medium, High)
- Mark tasks as complete/incomplete
- Edit and delete tasks
- Filter by status (All, Active, Completed)
- Sort by priority or date
- User authentication
- Responsive design

## Setup Instructions

### 1. Appwrite Setup

1. Create an Appwrite Cloud account at https://cloud.appwrite.io
2. Create a new project
3. Create a database named `taskmanager`
4. Create a collection named `tasks` with these attributes:
   - `title` (string, required)
   - `description` (string)
   - `priority` (enum: low, medium, high, default: medium)
   - `completed` (boolean, default: false)
   - `userId` (string, required)
   - `userName` (string, required)
   - `createdAt` (datetime, required)
   - `completedAt` (datetime, optional)

5. Set permissions:
   - Create: `users`
   - Read: `user:{userId}` (users can only read their own tasks)
   - Update: `user:{userId}`
   - Delete: `user:{userId}`

6. Enable Email/Password authentication in Auth settings

### 2. Environment Variables

Create a `.env.local` file:

```
NEXT_PUBLIC_APPWRITE_PROJECT_ID=your_project_id
NEXT_PUBLIC_APPWRITE_ENDPOINT=https://cloud.appwrite.io/v1
NEXT_PUBLIC_DATABASE_ID=taskmanager
NEXT_PUBLIC_TASKS_COLLECTION_ID=tasks
```

### 3. Run the App

```bash
npm install
npm run dev
```

Visit http://localhost:3000

## Project Structure

```
src/
├── app/
│   ├── api/
│   │   └── tasks/
│   │       └── route.ts
│   ├── components/
│   │   ├── TaskList.tsx
│   │   ├── TaskItem.tsx
│   │   ├── TaskForm.tsx
│   │   ├── TaskFilters.tsx
│   │   ├── Navbar.tsx
│   │   └── AuthProvider.tsx
│   ├── auth/
│   │   ├── signin/
│   │   │   └── page.tsx
│   │   └── signup/
│   │       └── page.tsx
│   ├── layout.tsx
│   └── page.tsx
├── lib/
│   ├── appwrite.ts
│   └── auth.ts
└── types/
    └── task.ts
```

## Key Learnings

- Full CRUD operations with Appwrite
- Client-side filtering and sorting
- User authentication and authorization
- Form handling in React
- Component composition

## License

MIT
