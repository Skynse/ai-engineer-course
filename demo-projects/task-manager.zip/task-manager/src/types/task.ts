export type Priority = 'low' | 'medium' | 'high';
export type TaskStatus = 'backlog' | 'in-progress' | 'done';
export type PriorityFilter = 'all' | Priority;

export interface Task {
  $id: string;
  title: string;
  description: string;
  priority: Priority;
  status: TaskStatus;
  order: string;
  completed: boolean;
  userId: string;
  userName: string;
  createdAt: string;
  completedAt?: string;
}

export const TASK_STATUSES: TaskStatus[] = ['backlog', 'in-progress', 'done'];

export const TASK_STATUS_LABELS: Record<TaskStatus, string> = {
  backlog: 'Backlog',
  'in-progress': 'In Progress',
  done: 'Done',
};
