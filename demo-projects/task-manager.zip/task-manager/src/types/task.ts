export interface Task {
  $id: string;
  title: string;
  description: string;
  priority: 'low' | 'medium' | 'high';
  completed: boolean;
  userId: string;
  userName: string;
  createdAt: string;
  completedAt?: string;
}

export type Priority = 'low' | 'medium' | 'high';
export type FilterStatus = 'all' | 'active' | 'completed';
export type SortBy = 'date' | 'priority';
