const ALPHABET = '0123456789abcdefghijklmnopqrstuvwxyz';
const MIN_CHAR_INDEX = 0;
const MAX_CHAR_INDEX = ALPHABET.length - 1;

function getCharIndex(char: string) {
  const index = ALPHABET.indexOf(char);

  if (index === -1) {
    throw new Error(`Invalid LexoRank character: ${char}`);
  }

  return index;
}

export function generateLexoRankBetween(lower?: string | null, upper?: string | null) {
  const left = (lower ?? '').toLowerCase();
  const right = (upper ?? '').toLowerCase();

  if (left && right && left >= right) {
    throw new Error(`Invalid LexoRank boundaries: "${left}" must be less than "${right}"`);
  }

  let prefix = '';
  let position = 0;

  while (true) {
    const leftIndex = position < left.length ? getCharIndex(left[position]) : MIN_CHAR_INDEX;
    const rightIndex = position < right.length ? getCharIndex(right[position]) : MAX_CHAR_INDEX;

    if (rightIndex - leftIndex > 1) {
      const middleIndex = Math.floor((leftIndex + rightIndex) / 2);
      return `${prefix}${ALPHABET[middleIndex]}`;
    }

    prefix += ALPHABET[leftIndex];
    position += 1;
  }
}
