'use client';

import { useCallback, useEffect, useMemo, useState } from 'react';
import { Task, Priority, TaskStatus, TASK_STATUSES } from '@/types/task';
import { useAuth } from './components/AuthProvider';
import { databases, DATABASE_ID, TASKS_COLLECTION_ID, ID } from '@/lib/appwrite';
import { Models, Query } from 'appwrite';
import Navbar from './components/Navbar';
import TaskList from './components/TaskList';
import TaskForm from './components/TaskForm';
import { useRouter } from 'next/navigation';
import { generateLexoRankBetween } from '@/lib/lexorank';

interface DropTarget {
  status: TaskStatus;
  index: number;
}

function isTaskStatus(value: unknown): value is TaskStatus {
  return value === 'backlog' || value === 'in-progress' || value === 'done';
}

function sortTasksByOrder(tasks: Task[]) {
  return [...tasks].sort((a, b) => {
    const orderA = a.order || '';
    const orderB = b.order || '';

    if (orderA && orderB && orderA !== orderB) {
      return orderA.localeCompare(orderB);
    }

    if (orderA && !orderB) return -1;
    if (!orderA && orderB) return 1;

    return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
  });
}

function normalizeTask(document: Models.Document): Task {
  const status = isTaskStatus(document.status)
    ? document.status
    : document.completed
      ? 'done'
      : 'backlog';

  return {
    $id: document.$id,
    title: String(document.title ?? ''),
    description: String(document.description ?? ''),
    priority: (document.priority as Priority) ?? 'medium',
    status,
    order: typeof document.order === 'string' ? document.order : '',
    completed: status === 'done' || Boolean(document.completed),
    userId: String(document.userId ?? ''),
    userName: String(document.userName ?? 'Anonymous'),
    createdAt: String(document.$createdAt),
    completedAt: document.completedAt ? String(document.completedAt) : undefined,
  };
}

export default function Home() {
  const { user, loading: authLoading } = useAuth();
  const router = useRouter();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [draftStatus, setDraftStatus] = useState<TaskStatus>('backlog');
  const [draggedTaskId, setDraggedTaskId] = useState<string | null>(null);
  const [dropTarget, setDropTarget] = useState<DropTarget | null>(null);

  const loadTasks = useCallback(async () => {
    try {
      const response = await databases.listDocuments(
        DATABASE_ID,
        TASKS_COLLECTION_ID,
        [Query.orderAsc('$createdAt')]
      );

      const originalStatusById = new Map<string, unknown>();
      response.documents.forEach((document) => {
        originalStatusById.set(document.$id, document.status);
      });

      const normalizedTasks = response.documents.map(normalizeTask);
      const updates: Promise<unknown>[] = [];

      TASK_STATUSES.forEach((status) => {
        const orderedColumn = sortTasksByOrder(normalizedTasks.filter((task) => task.status === status));
        let previousOrder: string | undefined;

        orderedColumn.forEach((task) => {
          const desiredOrder = previousOrder
            ? generateLexoRankBetween(previousOrder, undefined)
            : generateLexoRankBetween(undefined, undefined);

          const needsStatusRepair = !isTaskStatus(originalStatusById.get(task.$id));
          const needsOrderRepair = !task.order;

          previousOrder = task.order || desiredOrder;

          if (needsStatusRepair || needsOrderRepair) {
            updates.push(
              databases.updateDocument(DATABASE_ID, TASKS_COLLECTION_ID, task.$id, {
                status: task.status,
                order: task.order || desiredOrder,
                completed: task.status === 'done',
                completedAt: task.status === 'done' ? task.completedAt ?? new Date().toISOString() : null,
              })
            );
          }
        });
      });

      if (updates.length > 0) {
        await Promise.all(updates);
        const repairedResponse = await databases.listDocuments(
          DATABASE_ID,
          TASKS_COLLECTION_ID,
          [Query.orderAsc('$createdAt')]
        );
        setTasks(repairedResponse.documents.map(normalizeTask));
      } else {
        setTasks(normalizedTasks);
      }
    } catch (error) {
      console.error('Error loading tasks:', error);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (!authLoading && !user) {
      router.push('/auth/signin');
      return;
    }

    if (user) {
      void loadTasks();
    }
  }, [authLoading, loadTasks, router, user]);

  const groupedTasks = useMemo(() => {
    return TASK_STATUSES.reduce<Record<TaskStatus, Task[]>>((acc, status) => {
      acc[status] = sortTasksByOrder(tasks.filter((task) => task.status === status));
      return acc;
    }, {
      backlog: [],
      'in-progress': [],
      done: [],
    });
  }, [tasks]);

  const totalTasks = tasks.length;
  const completedTasks = groupedTasks.done.length;
  const inProgressTasks = groupedTasks['in-progress'].length;

  function getColumnTasks(status: TaskStatus, excludeTaskId?: string) {
    return sortTasksByOrder(
      tasks.filter((task) => task.status === status && task.$id !== excludeTaskId)
    );
  }

  function getAppendOrder(status: TaskStatus) {
    const columnTasks = getColumnTasks(status);
    const lastTask = columnTasks[columnTasks.length - 1];
    return generateLexoRankBetween(lastTask?.order, undefined);
  }

  async function handleAddTask(data: { title: string; description: string; priority: Priority; status: TaskStatus }) {
    if (!user) return;

    try {
      const order = getAppendOrder(data.status);
      const isDone = data.status === 'done';

      await databases.createDocument(
        DATABASE_ID,
        TASKS_COLLECTION_ID,
        ID.unique(),
        {
          title: data.title,
          description: data.description,
          priority: data.priority,
          status: data.status,
          order,
          completed: isDone,
          completedAt: isDone ? new Date().toISOString() : null,
          userId: user.$id,
          userName: user.name || 'Anonymous'
        }
      );
      setShowForm(false);
      await loadTasks();
    } catch (error) {
      console.error('Error adding task:', error);
    }
  }

  async function handleEditTask(data: { title: string; description: string; priority: Priority; status: TaskStatus }) {
    if (!editingTask) return;

    try {
      const isStatusChange = editingTask.status !== data.status;
      const isDone = data.status === 'done';

      await databases.updateDocument(
        DATABASE_ID,
        TASKS_COLLECTION_ID,
        editingTask.$id,
        {
          title: data.title,
          description: data.description,
          priority: data.priority,
          status: data.status,
          order: isStatusChange ? getAppendOrder(data.status) : editingTask.order,
          completed: isDone,
          completedAt: isDone ? editingTask.completedAt ?? new Date().toISOString() : null
        }
      );
      setEditingTask(null);
      setShowForm(false);
      await loadTasks();
    } catch (error) {
      console.error('Error updating task:', error);
    }
  }

  async function handleMoveToStatus(task: Task, status: TaskStatus) {
    try {
      const isDone = status === 'done';

      await databases.updateDocument(
        DATABASE_ID,
        TASKS_COLLECTION_ID,
        task.$id,
        {
          status,
          order: getAppendOrder(status),
          completed: isDone,
          completedAt: isDone ? task.completedAt ?? new Date().toISOString() : null
        }
      );
      await loadTasks();
    } catch (error) {
      console.error('Error moving task:', error);
    }
  }

  async function handleDropTask(status: TaskStatus, index: number) {
    if (!draggedTaskId) {
      return;
    }

    const task = tasks.find((item) => item.$id === draggedTaskId);
    if (!task) {
      setDraggedTaskId(null);
      setDropTarget(null);
      return;
    }

    const targetTasks = getColumnTasks(status, task.$id);
    const clampedIndex = Math.max(0, Math.min(index, targetTasks.length));
    const previousTask = targetTasks[clampedIndex - 1];
    const nextTask = targetTasks[clampedIndex];
    const newOrder = generateLexoRankBetween(previousTask?.order, nextTask?.order);
    const isDone = status === 'done';

    try {
      await databases.updateDocument(
        DATABASE_ID,
        TASKS_COLLECTION_ID,
        task.$id,
        {
          status,
          order: newOrder,
          completed: isDone,
          completedAt: isDone ? task.completedAt ?? new Date().toISOString() : null
        }
      );
      await loadTasks();
    } catch (error) {
      console.error('Error dropping task:', error);
    } finally {
      setDraggedTaskId(null);
      setDropTarget(null);
    }
  }

  async function handleDeleteTask(id: string) {
    if (!confirm('Are you sure you want to delete this task?')) return;

    try {
      await databases.deleteDocument(DATABASE_ID, TASKS_COLLECTION_ID, id);
      await loadTasks();
    } catch (error) {
      console.error('Error deleting task:', error);
    }
  }

  if (authLoading || loading) {
    return <div className="p-8 text-center text-slate-600">Loading...</div>;
  }

  if (!user) return null;

  return (
    <div className="min-h-screen bg-[#f4f6f9] text-slate-900">
      <Navbar />

      <main className="px-5 py-5 lg:px-8 lg:py-6">
        <div className="mx-auto max-w-[1560px]">
          <section className="mb-5 rounded-[28px] border border-slate-200/70 bg-white px-5 py-5 shadow-[0_16px_40px_rgba(15,23,42,0.06)]">
            <div className="flex flex-col gap-5 lg:flex-row lg:items-end lg:justify-between">
              <div>
                <p className="text-[10px] font-semibold uppercase tracking-[0.24em] text-slate-400">
                  Active board
                </p>
                <h2 className="mt-2 text-3xl font-bold tracking-tight text-slate-900">
                  Course production sprint
                </h2>
                <p className="mt-2 max-w-2xl text-sm text-slate-500">
                  Keep the board dense, fast to scan, and focused on shipping lessons and demos.
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <div className="rounded-full border border-slate-200 bg-slate-50 px-4 py-2 text-sm text-slate-600">
                  <span className="font-semibold text-slate-900">{totalTasks}</span> total cards
                </div>
                <div className="rounded-full border border-amber-200 bg-amber-50 px-4 py-2 text-sm text-amber-700">
                  <span className="font-semibold">{inProgressTasks}</span> in progress
                </div>
                <div className="rounded-full border border-emerald-200 bg-emerald-50 px-4 py-2 text-sm text-emerald-700">
                  <span className="font-semibold">{completedTasks}</span> complete
                </div>
                <button
                  onClick={() => {
                    setEditingTask(null);
                    setDraftStatus('backlog');
                    setShowForm(true);
                  }}
                  className="rounded-full bg-slate-900 px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-slate-700"
                >
                  Add task
                </button>
              </div>
            </div>
          </section>

          {showForm && (
            <div className="fixed inset-0 z-50 flex items-start justify-center bg-slate-950/30 px-4 py-8 backdrop-blur-[2px]">
              <div className="w-full max-w-4xl">
                <TaskForm
                  initialData={editingTask ? {
                    title: editingTask.title,
                    description: editingTask.description,
                    priority: editingTask.priority,
                    status: editingTask.status,
                  } : {
                    title: '',
                    description: '',
                    priority: 'medium',
                    status: draftStatus,
                  }}
                  onSubmit={editingTask ? handleEditTask : handleAddTask}
                  onCancel={() => {
                    setShowForm(false);
                    setEditingTask(null);
                  }}
                  submitLabel={editingTask ? 'Update task' : 'Create task'}
                />
              </div>
            </div>
          )}

          <TaskList
            tasksByStatus={groupedTasks}
            onDelete={handleDeleteTask}
            onEdit={(task) => {
              setEditingTask(task);
              setDraftStatus(task.status);
              setShowForm(true);
            }}
            onMoveToStatus={handleMoveToStatus}
            onCreateInStatus={(status) => {
              setEditingTask(null);
              setDraftStatus(status);
              setShowForm(true);
            }}
            onDragStart={(taskId) => {
              setDraggedTaskId(taskId);
            }}
            onDragEnd={() => {
              setDraggedTaskId(null);
              setDropTarget(null);
            }}
            onDragTargetChange={(target) => {
              setDropTarget(target);
            }}
            onDropTask={(status, index) => void handleDropTask(status, index)}
            draggedTaskId={draggedTaskId}
            dropTarget={dropTarget}
            dragEnabled={true}
          />
        </div>
      </main>
    </div>
  );
}
