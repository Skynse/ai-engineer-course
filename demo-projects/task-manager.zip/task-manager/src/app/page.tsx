'use client';

import { useState, useEffect } from 'react';
import { Task, FilterStatus, SortBy } from '@/types/task';
import { useAuth } from './components/AuthProvider';
import Navbar from './components/Navbar';
import TaskList from './components/TaskList';
import TaskForm from './components/TaskForm';
import TaskFilters from './components/TaskFilters';
import { useRouter } from 'next/navigation';

export default function Home() {
  const { user, loading: authLoading } = useAuth();
  const router = useRouter();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [filter, setFilter] = useState<FilterStatus>('all');
  const [sortBy, setSortBy] = useState<SortBy>('date');

  useEffect(() => {
    if (!authLoading && !user) {
      router.push('/auth/signin');
      return;
    }
    if (user) {
      loadTasks();
    }
  }, [user, authLoading]);

  async function loadTasks() {
    try {
      const response = await fetch('/api/tasks');
      const data = await response.json();
      setTasks(data.tasks || []);
    } catch (error) {
      console.error('Error loading tasks:', error);
    } finally {
      setLoading(false);
    }
  }

  const filteredTasks = tasks.filter((task) => {
    if (filter === 'active') return !task.completed;
    if (filter === 'completed') return task.completed;
    return true;
  }).sort((a, b) => {
    if (sortBy === 'date') {
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    }
    const priorityOrder = { high: 3, medium: 2, low: 1 };
    return priorityOrder[b.priority] - priorityOrder[a.priority];
  });

  const taskCount = {
    all: tasks.length,
    active: tasks.filter((t) => !t.completed).length,
    completed: tasks.filter((t) => t.completed).length
  };

  async function handleAddTask(data: { title: string; description: string; priority: SortBy }) {
    if (!user) return;

    try {
      const response = await fetch('/api/tasks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...data,
          userId: user.$id,
          userName: user.name
        })
      });

      if (response.ok) {
        setShowForm(false);
        loadTasks();
      }
    } catch (error) {
      console.error('Error adding task:', error);
    }
  }

  async function handleEditTask(data: { title: string; description: string; priority: SortBy }) {
    if (!editingTask) return;

    try {
      const response = await fetch(`/api/tasks/${editingTask.$id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });

      if (response.ok) {
        setEditingTask(null);
        setShowForm(false);
        loadTasks();
      }
    } catch (error) {
      console.error('Error updating task:', error);
    }
  }

  async function handleToggleTask(id: string, completed: boolean) {
    try {
      await fetch(`/api/tasks/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ completed })
      });
      loadTasks();
    } catch (error) {
      console.error('Error toggling task:', error);
    }
  }

  async function handleDeleteTask(id: string) {
    if (!confirm('Are you sure you want to delete this task?')) return;

    try {
      await fetch(`/api/tasks/${id}`, { method: 'DELETE' });
      loadTasks();
    } catch (error) {
      console.error('Error deleting task:', error);
    }
  }

  if (authLoading || loading) {
    return <div className="text-center p-8">Loading...</div>;
  }

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gray-100">
      <Navbar />
      <main className="max-w-4xl mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">My Tasks</h1>
          <p className="text-gray-600">Stay organized and get things done</p>
        </div>

        <button
          onClick={() => {
            setEditingTask(null);
            setShowForm(!showForm);
          }}
          className="w-full bg-blue-500 text-white py-3 rounded-lg hover:bg-blue-600 font-semibold mb-6 transition-colors"
        >
          {showForm ? 'Cancel' : '+ Add New Task'}
        </button>

        {showForm && (
          <div className="mb-6">
            <TaskForm
              initialData={editingTask ? {
                title: editingTask.title,
                description: editingTask.description,
                priority: editingTask.priority
              } : undefined}
              onSubmit={editingTask ? handleEditTask : handleAddTask}
              onCancel={() => {
                setShowForm(false);
                setEditingTask(null);
              }}
              submitLabel={editingTask ? 'Update Task' : 'Add Task'}
            />
          </div>
        )}

        <TaskFilters
          filter={filter}
          sortBy={sortBy}
          onFilterChange={setFilter}
          onSortChange={setSortBy}
          taskCount={taskCount}
        />

        <TaskList
          tasks={filteredTasks}
          onToggle={handleToggleTask}
          onDelete={handleDeleteTask}
          onEdit={(task) => {
            setEditingTask(task);
            setShowForm(true);
          }}
        />
      </main>
    </div>
  );
}
