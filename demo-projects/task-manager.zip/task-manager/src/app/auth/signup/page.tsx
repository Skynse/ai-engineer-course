'use client';

import { useState } from 'react';
import { signUp } from '@/lib/auth';
import { useAuth } from '@/app/components/AuthProvider';
import Link from 'next/link';
import { useRouter } from 'next/navigation';

function getErrorMessage(error: unknown) {
  return error instanceof Error ? error.message : 'Failed to sign up';
}

export default function SignUp() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const router = useRouter();
  const { refreshUser } = useAuth();

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      await signUp(email, password, name);
      await refreshUser();
      router.push('/');
    } catch (err: unknown) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-[radial-gradient(circle_at_top_right,_rgba(148,163,184,0.26),_transparent_35%),linear-gradient(135deg,_#f8f5ef,_#ece7dd)] px-4 py-10">
      <div className="w-full max-w-md rounded-[2rem] border border-white/70 bg-[rgba(255,255,255,0.9)] p-8 shadow-[0_30px_80px_rgba(15,23,42,0.12)] backdrop-blur-xl">
        <p className="text-sm font-semibold uppercase tracking-[0.32em] text-slate-500">Task Orbit</p>
        <h2 className="mt-4 text-4xl font-black tracking-tight text-slate-900">Build your command center.</h2>
        <p className="mt-3 text-sm leading-6 text-slate-600">
          Create an account to organize work, surface priorities, and keep your course demos crisp.
        </p>

        {error && (
          <div className="mt-6 rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">{error}</div>
        )}

        <form onSubmit={handleSubmit} className="mt-8 space-y-5">
          <div>
            <label className="mb-2 block text-sm font-semibold text-slate-700">Name</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-slate-900 outline-none transition focus:border-amber-400 focus:ring-4 focus:ring-amber-100"
              placeholder="Ada Lovelace"
              required
            />
          </div>

          <div>
            <label className="mb-2 block text-sm font-semibold text-slate-700">Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-slate-900 outline-none transition focus:border-amber-400 focus:ring-4 focus:ring-amber-100"
              placeholder="you@example.com"
              required
            />
          </div>

          <div>
            <label className="mb-2 block text-sm font-semibold text-slate-700">Password</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-slate-900 outline-none transition focus:border-amber-400 focus:ring-4 focus:ring-amber-100"
              placeholder="At least 8 characters"
              required
              minLength={8}
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full rounded-full bg-amber-400 px-5 py-3 text-sm font-bold uppercase tracking-[0.22em] text-slate-900 transition hover:bg-amber-300 disabled:cursor-not-allowed disabled:opacity-50"
          >
            {loading ? 'Creating Account...' : 'Launch Board'}
          </button>
        </form>

        <p className="mt-6 text-center text-sm text-slate-600">
          Already have an account?{' '}
          <Link href="/auth/signin" className="font-semibold text-slate-900 underline decoration-amber-400 underline-offset-4">
            Sign in
          </Link>
        </p>
      </div>
    </div>
  );
}
