import { NextResponse } from 'next/server';
import { databases, DATABASE_ID, TASKS_COLLECTION_ID } from '@/lib/appwrite';

export async function PATCH(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const body = await request.json();
    const updates: any = {};
    
    if (body.title !== undefined) updates.title = body.title.trim();
    if (body.description !== undefined) updates.description = body.description.trim();
    if (body.priority !== undefined) updates.priority = body.priority;
    if (body.completed !== undefined) {
      updates.completed = body.completed;
      updates.completedAt = body.completed ? new Date().toISOString() : null;
    }

    const task = await databases.updateDocument(
      DATABASE_ID,
      TASKS_COLLECTION_ID,
      params.id,
      updates
    );

    return NextResponse.json({ task });
  } catch (error) {
    console.error('Error updating task:', error);
    return NextResponse.json(
      { error: 'Failed to update task' },
      { status: 500 }
    );
  }
}

export async function DELETE(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    await databases.deleteDocument(
      DATABASE_ID,
      TASKS_COLLECTION_ID,
      params.id
    );
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting task:', error);
    return NextResponse.json(
      { error: 'Failed to delete task' },
      { status: 500 }
    );
  }
}
