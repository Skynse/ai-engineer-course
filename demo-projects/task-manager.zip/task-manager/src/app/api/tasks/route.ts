import { NextResponse } from 'next/server';
import { databases, DATABASE_ID, TASKS_COLLECTION_ID } from '@/lib/appwrite';
import { ID, Query } from 'appwrite';

export async function GET() {
  try {
    const tasks = await databases.listDocuments(
      DATABASE_ID,
      TASKS_COLLECTION_ID,
      [Query.orderDesc('$createdAt')]
    );
    return NextResponse.json({ tasks: tasks.documents });
  } catch (error) {
    console.error('Error fetching tasks:', error);
    return NextResponse.json(
      { error: 'Failed to fetch tasks' },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { title, description, priority, userId, userName } = body;

    if (!title?.trim() || !userId) {
      return NextResponse.json(
        { error: 'Title and user are required' },
        { status: 400 }
      );
    }

    const task = await databases.createDocument(
      DATABASE_ID,
      TASKS_COLLECTION_ID,
      ID.unique(),
      {
        title: title.trim(),
        description: description?.trim() || '',
        priority: priority || 'medium',
        completed: false,
        userId,
        userName: userName || 'Anonymous',
        createdAt: new Date().toISOString()
      }
    );

    return NextResponse.json({ task }, { status: 201 });
  } catch (error) {
    console.error('Error creating task:', error);
    return NextResponse.json(
      { error: 'Failed to create task' },
      { status: 500 }
    );
  }
}
