'use client';

import { FilterStatus, SortBy } from '@/types/task';

interface TaskFiltersProps {
  filter: FilterStatus;
  sortBy: SortBy;
  onFilterChange: (filter: FilterStatus) => void;
  onSortChange: (sort: SortBy) => void;
  taskCount: { all: number; active: number; completed: number };
}

export default function TaskFilters({
  filter,
  sortBy,
  onFilterChange,
  onSortChange,
  taskCount
}: TaskFiltersProps) {
  return (
    <div className="bg-white p-4 rounded-lg shadow mb-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex gap-2">
          {(['all', 'active', 'completed'] as FilterStatus[]).map((f) => (
            <button
              key={f}
              onClick={() => onFilterChange(f)}
              className={`px-4 py-2 rounded-lg capitalize font-medium transition-colors ${
                filter === f
                  ? 'bg-blue-500 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              {f}
              <span className="ml-2 text-sm opacity-75">
                ({f === 'all' ? taskCount.all : f === 'active' ? taskCount.active : taskCount.completed})
              </span>
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2">
          <label className="text-sm text-gray-600">Sort by:</label>
          <select
            value={sortBy}
            onChange={(e) => onSortChange(e.target.value as SortBy)}
            className="p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
          >
            <option value="date">Date Created</option>
            <option value="priority">Priority</option>
          </select>
        </div>
      </div>
    </div>
  );
}
