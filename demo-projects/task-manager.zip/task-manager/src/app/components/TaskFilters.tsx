'use client';

import { PriorityFilter } from '@/types/task';

interface TaskFiltersProps {
  priorityFilter: PriorityFilter;
  onPriorityFilterChange: (filter: PriorityFilter) => void;
  dragEnabled: boolean;
}

const filters: PriorityFilter[] = ['all', 'high', 'medium', 'low'];

export default function TaskFilters({ priorityFilter, onPriorityFilterChange, dragEnabled }: TaskFiltersProps) {
  return (
    <section className="mb-5 flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
      <div className="flex items-center gap-2">
        <p className="text-sm text-slate-500">
          {dragEnabled ? (
            <span className="inline-flex items-center gap-1">
              <svg className="h-4 w-4 text-emerald-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
              Drag & drop enabled
            </span>
          ) : (
            <span className="inline-flex items-center gap-1">
              <svg className="h-4 w-4 text-amber-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
              </svg>
              Filters active — drag disabled
            </span>
          )}
        </p>
      </div>

      <div className="flex flex-wrap gap-2">
        {filters.map((filter) => (
          <button
            key={filter}
            onClick={() => onPriorityFilterChange(filter)}
            className={`rounded-full px-3 py-1.5 text-xs font-medium capitalize transition ${
              priorityFilter === filter
                ? 'bg-slate-800 text-white shadow-sm'
                : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
            }`}
          >
            {filter === 'all' ? 'All' : filter}
          </button>
        ))}
      </div>
    </section>
  );
}
