'use client';

import { useState, useRef, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { Task } from '@/types/task';

interface TaskItemProps {
  task: Task;
  onDelete: () => void;
  onEdit: () => void;
  onDragStart: (taskId: string) => void;
  onDragEnd: () => void;
  isDragging: boolean;
  dragEnabled: boolean;
}

const priorityStyles = {
  low: { bg: 'bg-slate-100', text: 'text-slate-600', accent: 'bg-slate-300' },
  medium: { bg: 'bg-amber-100', text: 'text-amber-700', accent: 'bg-amber-400' },
  high: { bg: 'bg-rose-100', text: 'text-rose-700', accent: 'bg-rose-400' }
};

export default function TaskItem({
  task,
  onDelete,
  onEdit,
  onDragStart,
  onDragEnd,
  isDragging,
  dragEnabled,
}: TaskItemProps) {
  const [showMenu, setShowMenu] = useState(false);
  const [menuPos, setMenuPos] = useState({ top: 0, left: 0 });
  const menuButtonRef = useRef<HTMLButtonElement>(null);
  const menuRef = useRef<HTMLDivElement>(null);
  const priorityStyle = priorityStyles[task.priority];

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      const target = event.target as Node;
      const clickedButton = menuButtonRef.current?.contains(target);
      const clickedMenu = menuRef.current?.contains(target);
      
      if (!clickedButton && !clickedMenu) {
        setShowMenu(false);
      }
    }

    if (showMenu) {
      document.addEventListener('mousedown', handleClickOutside);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [showMenu]);

  function handleMenuClick(e: React.MouseEvent) {
    e.stopPropagation();
    if (!showMenu && menuButtonRef.current) {
      const rect = menuButtonRef.current.getBoundingClientRect();
      setMenuPos({
        top: rect.bottom + window.scrollY + 4,
        left: Math.max(8, rect.right + window.scrollX - 160)
      });
    }
    setShowMenu(!showMenu);
  }

  function handleEditClick(e: React.MouseEvent) {
    e.stopPropagation();
    setShowMenu(false);
    onEdit();
  }

  function handleDeleteClick(e: React.MouseEvent) {
    e.stopPropagation();
    setShowMenu(false);
    onDelete();
  }

  function handleDragStart(e: React.DragEvent) {
    if (!dragEnabled) {
      e.preventDefault();
      return;
    }
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', task.$id);
    onDragStart(task.$id);
  }

  const menuContent = (
    <div
      ref={menuRef}
      className="fixed z-[9999] w-36 rounded-2xl bg-white py-1 shadow-[0_18px_40px_rgba(15,23,42,0.16)] ring-1 ring-black ring-opacity-5"
      style={{ top: menuPos.top, left: menuPos.left }}
    >
      <button
        onMouseDown={(e) => e.stopPropagation()}
        onClick={handleEditClick}
        className="flex w-full items-center px-4 py-2 text-sm text-slate-700 transition-colors hover:bg-slate-50 text-left"
      >
        <svg className="mr-3 h-4 w-4 text-slate-400 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
        </svg>
        Edit
      </button>

      <div className="my-1 border-t border-slate-100" />

      <button
        onMouseDown={(e) => e.stopPropagation()}
        onClick={handleDeleteClick}
        className="flex w-full items-center px-4 py-2 text-sm text-red-600 transition-colors hover:bg-red-50 text-left"
      >
        <svg className="mr-3 h-4 w-4 text-red-400 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
        </svg>
        Delete
      </button>
    </div>
  );

  return (
    <>
      <article
        draggable={dragEnabled}
        onDragStart={handleDragStart}
        onDragEnd={onDragEnd}
        className={`group relative overflow-hidden rounded-[18px] border border-slate-200/70 bg-white shadow-[0_6px_18px_rgba(15,23,42,0.05)] transition-all duration-200 ${
          dragEnabled ? 'cursor-grab active:cursor-grabbing' : ''
        } ${isDragging ? 'scale-[0.99] opacity-50 shadow-none rotate-1' : 'hover:-translate-y-0.5 hover:shadow-[0_10px_24px_rgba(15,23,42,0.08)]'}`}
      >
        <div className={`absolute inset-y-0 left-0 w-1 ${priorityStyle.accent}`} />

        <div className="p-3 pl-4">
          <div className="mb-1.5 flex items-start justify-between gap-2">
            <h3 className="flex-1 text-[13px] font-semibold leading-5 text-slate-900">{task.title}</h3>
            <button
              ref={menuButtonRef}
              onClick={handleMenuClick}
              className="flex h-6 w-6 items-center justify-center rounded-md text-slate-400 opacity-0 transition hover:bg-slate-100 hover:text-slate-600 group-hover:opacity-100"
              aria-label="Open card menu"
            >
              <svg className="h-4 w-4" fill="currentColor" viewBox="0 0 20 20">
                <path d="M10 6a2 2 0 110-4 2 2 0 010 4zM10 12a2 2 0 110-4 2 2 0 010 4zM10 18a2 2 0 110-4 2 2 0 010 4z" />
              </svg>
            </button>
          </div>

          {task.description && (
            <p className="line-clamp-2 text-[12px] leading-4.5 text-slate-500">{task.description}</p>
          )}

          <div className="mt-3 flex items-center justify-between gap-2">
            <span className={`rounded-md px-2 py-1 text-[10px] font-bold uppercase tracking-[0.14em] ${priorityStyle.bg} ${priorityStyle.text}`}>
              {task.priority}
            </span>
            <span className="text-[10px] font-medium uppercase tracking-[0.14em] text-slate-400">
              {task.userName}
            </span>
          </div>
        </div>
      </article>

      {showMenu && createPortal(menuContent, document.body)}
    </>
  );
}
