'use client';

import Link from 'next/link';
import { useAuth } from './AuthProvider';

export default function Navbar() {
  const { user, loading, logout } = useAuth();

  return (
    <nav className="bg-white shadow-sm mb-8">
      <div className="max-w-4xl mx-auto px-4 py-4 flex justify-between items-center">
        <Link href="/" className="text-xl font-bold text-blue-600">
          Task Manager
        </Link>
        
        <div>
          {loading ? (
            <span className="text-gray-500">Loading...</span>
          ) : user ? (
            <div className="flex items-center gap-4">
              <span className="text-gray-700">Welcome, {user.name}!</span>
              <button
                onClick={logout}
                className="text-sm text-red-500 hover:text-red-700 font-medium"
              >
                Logout
              </button>
            </div>
          ) : (
            <div className="space-x-4">
              <Link href="/auth/signin" className="text-blue-500 hover:underline">
                Sign In
              </Link>
              <Link href="/auth/signup" className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">
                Sign Up
              </Link>
            </div>
          )}
        </div>
      </div>
    </nav>
  );
}
