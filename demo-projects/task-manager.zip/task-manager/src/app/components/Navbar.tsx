"use client";

import { useAuth } from "./AuthProvider";

export default function Navbar() {
  const { user, loading, logout } = useAuth();

  return (
    <header className="sticky top-0 z-40 border-b border-slate-200/80 bg-white/92 backdrop-blur-xl">
      <div className="mx-auto flex max-w-[1560px] items-center justify-between gap-4 px-5 py-3 lg:px-8">
        <div className="min-w-0">
          <p className="text-[10px] font-semibold uppercase tracking-[0.24em] text-slate-400">
            Project board
          </p>
          <div className="flex items-baseline gap-3">
            <h1 className="truncate text-lg font-bold tracking-tight text-slate-900">
              The Kinetic Archive
            </h1>
            <p className="hidden text-sm text-slate-500 md:block">Course production kanban</p>
          </div>
        </div>

        {loading ? (
          <span className="rounded-full border border-slate-200 bg-slate-50 px-3 py-1.5 text-sm text-slate-500">
            Loading
          </span>
        ) : user ? (
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-2 rounded-full border border-slate-200 bg-white px-2 py-1.5">
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-sky-100 text-xs font-bold text-sky-700">
                {user.name?.charAt(0).toUpperCase() || "?"}
              </div>
              <span className="hidden pr-1 text-sm font-medium text-slate-700 sm:block">
                {user.name}
              </span>
            </div>
            <button
              onClick={logout}
              className="rounded-full border border-slate-200 bg-white px-4 py-2 text-sm font-medium text-slate-700 transition hover:border-slate-300 hover:bg-slate-50"
            >
              Log out
            </button>
          </div>
        ) : null}
      </div>
    </header>
  );
}
