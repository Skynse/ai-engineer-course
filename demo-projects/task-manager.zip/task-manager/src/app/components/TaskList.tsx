'use client';

import { DragEvent } from 'react';
import { Task, TaskStatus, TASK_STATUSES, TASK_STATUS_LABELS } from '@/types/task';
import TaskItem from './TaskItem';

interface DropTarget {
  status: TaskStatus;
  index: number;
}

interface TaskListProps {
  tasksByStatus: Record<TaskStatus, Task[]>;
  onDelete: (id: string) => void;
  onEdit: (task: Task) => void;
  onMoveToStatus: (task: Task, status: TaskStatus) => void;
  onCreateInStatus: (status: TaskStatus) => void;
  onDragStart: (taskId: string) => void;
  onDragEnd: () => void;
  onDragTargetChange: (target: DropTarget | null) => void;
  onDropTask: (status: TaskStatus, index: number) => void;
  draggedTaskId: string | null;
  dropTarget: DropTarget | null;
  dragEnabled: boolean;
}

const columnConfig: Record<TaskStatus, { bg: string; headerBg: string; accent: string; countBg: string; countText: string }> = {
  backlog: {
    bg: 'bg-[#fcf6f4]',
    headerBg: 'bg-transparent',
    accent: 'border-l-red-400',
    countBg: 'bg-red-100',
    countText: 'text-red-700'
  },
  'in-progress': {
    bg: 'bg-[#fdfaf1]',
    headerBg: 'bg-transparent',
    accent: 'border-l-amber-400',
    countBg: 'bg-amber-100',
    countText: 'text-amber-700'
  },
  done: {
    bg: 'bg-[#f2fbf5]',
    headerBg: 'bg-transparent',
    accent: 'border-l-emerald-400',
    countBg: 'bg-emerald-100',
    countText: 'text-emerald-700'
  }
};

function DropSlot({ active, onDragEnter, onDrop, dragEnabled }: {
  active: boolean;
  onDragEnter: () => void;
      onDrop: () => void;
      dragEnabled: boolean;
}) {
  function handleDragOver(event: DragEvent<HTMLDivElement>) {
    if (!dragEnabled) return;
    event.preventDefault();
    event.dataTransfer.dropEffect = 'move';
  }

  return (
    <div
      onDragEnter={dragEnabled ? onDragEnter : undefined}
      onDragOver={handleDragOver}
      onDrop={dragEnabled ? (event) => {
        event.preventDefault();
        onDrop();
      } : undefined}
      className={`rounded-xl border border-dashed transition ${
        active
          ? 'my-2 h-12 border-sky-300 bg-sky-100/80'
          : dragEnabled
            ? 'my-1 h-2 border-transparent bg-transparent'
            : 'hidden'
      }`}
    />
  );
}

function MoreMenuButton() {
  return (
    <button className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 transition hover:bg-slate-200/50 hover:text-slate-600">
      <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 20 20">
        <path d="M10 6a2 2 0 110-4 2 2 0 010 4zM10 12a2 2 0 110-4 2 2 0 010 4zM10 18a2 2 0 110-4 2 2 0 010 4z" />
      </svg>
    </button>
  );
}

export default function TaskList({
  tasksByStatus,
  onDelete,
  onEdit,
  onMoveToStatus,
  onCreateInStatus,
  onDragStart,
  onDragEnd,
  onDragTargetChange,
  onDropTask,
  draggedTaskId,
  dropTarget,
  dragEnabled,
}: TaskListProps) {
  return (
    <div className="overflow-x-auto pb-6">
      <div className="flex min-w-max items-start gap-4">
        {TASK_STATUSES.map((status) => {
          const tasks = tasksByStatus[status];
          const config = columnConfig[status];

          return (
            <section key={status} className={`w-[292px] shrink-0 rounded-[24px] border border-slate-200/70 ${config.bg}`}>
              <div className={`flex items-center justify-between rounded-t-[24px] border-b border-slate-200/55 px-4 py-3 ${config.headerBg}`}>
                <div className="flex items-center gap-3">
                  <div className={`h-6 w-1 rounded-full ${config.accent.replace('border-l-', 'bg-')}`} />
                  <h3 className="text-[14px] font-bold text-slate-800">{TASK_STATUS_LABELS[status]}</h3>
                  <span className={`flex h-7 min-w-7 items-center justify-center rounded-full px-2 text-[11px] font-bold ${config.countBg} ${config.countText}`}>
                    {tasks.length}
                  </span>
                </div>
                <MoreMenuButton />
              </div>

              <div className="space-y-1 px-3 py-3">
                <DropSlot
                  active={dropTarget?.status === status && dropTarget.index === 0}
                  onDragEnter={() => onDragTargetChange({ status, index: 0 })}
                  onDrop={() => onDropTask(status, 0)}
                  dragEnabled={dragEnabled}
                />

                {tasks.length === 0 ? (
                  <div className="rounded-[18px] border border-dashed border-slate-300/60 bg-white/65 px-4 py-10 text-center text-sm text-slate-400">
                    No cards
                  </div>
                ) : (
                  tasks.map((task, index) => (
                    <div key={task.$id}>
                      <TaskItem
                        task={task}
                        onDelete={() => onDelete(task.$id)}
                        onEdit={() => onEdit(task)}
                        onDragStart={onDragStart}
                        onDragEnd={onDragEnd}
                        isDragging={draggedTaskId === task.$id}
                        dragEnabled={dragEnabled}
                      />
                      <DropSlot
                        active={dropTarget?.status === status && dropTarget.index === index + 1}
                        onDragEnter={() => onDragTargetChange({ status, index: index + 1 })}
                        onDrop={() => onDropTask(status, index + 1)}
                        dragEnabled={dragEnabled}
                      />
                    </div>
                  ))
                )}
              </div>

              <div className="px-3 pb-3">
                <button
                  onClick={() => onCreateInStatus(status)}
                  className="flex w-full items-center gap-2 rounded-[18px] px-3 py-2.5 text-sm font-medium text-slate-500 transition hover:bg-white/80 hover:text-slate-700"
                >
                  <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                  </svg>
                  <span>Add card</span>
                </button>
              </div>
            </section>
          );
        })}
      </div>
    </div>
  );
}
