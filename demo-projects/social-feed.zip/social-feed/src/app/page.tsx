'use client';

import { useCallback, useEffect, useMemo, useState } from 'react';
import { Models, Query } from 'appwrite';
import { useRouter } from 'next/navigation';
import Navbar from './components/Navbar';
import { useAuth } from './components/AuthProvider';
import {
  BUCKET_ID,
  COMMENTS_COLLECTION_ID,
  DATABASE_ID,
  databases,
  ID,
  POSTS_COLLECTION_ID,
  storage,
} from '@/lib/appwrite';

interface Post {
  $id: string;
  content: string;
  userId: string;
  userName: string;
  likes: string[];
  imageId: string;
  $createdAt: string;
}

interface Comment {
  $id: string;
  postId: string;
  content: string;
  userId: string;
  userName: string;
  $createdAt: string;
}

function normalizePost(document: Models.Document): Post {
  return {
    $id: document.$id,
    content: String(document.content ?? ''),
    userId: String(document.userId ?? ''),
    userName: String(document.userName ?? 'Anonymous'),
    likes: Array.isArray(document.likes) ? document.likes.map((value) => String(value)) : [],
    imageId: String(document.imageId ?? ''),
    $createdAt: String(document.$createdAt),
  };
}

function normalizeComment(document: Models.Document): Comment {
  return {
    $id: document.$id,
    postId: String(document.postId ?? ''),
    content: String(document.content ?? ''),
    userId: String(document.userId ?? ''),
    userName: String(document.userName ?? 'Anonymous'),
    $createdAt: String(document.$createdAt),
  };
}

function getInitials(name: string) {
  return (
    name
      .split(' ')
      .filter(Boolean)
      .slice(0, 2)
      .map((part) => part[0]?.toUpperCase() ?? '')
      .join('') || '?'
  );
}

function getTimeSince(dateString: string) {
  const diffMs = Date.now() - new Date(dateString).getTime();
  const diffMinutes = Math.max(1, Math.floor(diffMs / 60000));

  if (diffMinutes < 60) return `${diffMinutes}m ago`;

  const diffHours = Math.floor(diffMinutes / 60);
  if (diffHours < 24) return `${diffHours}h ago`;

  const diffDays = Math.floor(diffHours / 24);
  return `${diffDays}d ago`;
}

function formatPostDate(dateString: string) {
  const date = new Date(dateString);
  return date.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

function hashString(input: string) {
  let hash = 0;
  for (let i = 0; i < input.length; i += 1) {
    hash = (hash << 5) - hash + input.charCodeAt(i);
    hash |= 0;
  }
  return Math.abs(hash);
}

function postTag(content: string) {
  const hashtag = content.match(/#(\w+)/)?.[1];
  return hashtag ? hashtag.toUpperCase() : 'MOMENT';
}

function excerptTitle(content: string) {
  const cleaned = content.replace(/\s+/g, ' ').trim();
  if (!cleaned) return 'Untitled update';
  if (cleaned.length <= 46) return cleaned;
  return `${cleaned.slice(0, 46).trimEnd()}...`;
}

function colorBand(postId: string) {
  const palette = [
    'from-[#d6e5e0] to-[#eef3f1]',
    'from-[#dfe9eb] to-[#f2f5f5]',
    'from-[#d9e3ec] to-[#eef2f6]',
    'from-[#e4e3d8] to-[#f3f2ea]',
  ];
  return palette[hashString(postId) % palette.length];
}

function imageUrl(imageId: string) {
  if (!imageId) return '';
  return String(storage.getFileView(BUCKET_ID, imageId));
}

function HeartIcon({ filled }: { filled: boolean }) {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true" className="h-5 w-5">
      <path
        d="M12 21 10.2 19.4C5.1 14.7 2 11.9 2 8.4A4.7 4.7 0 0 1 6.8 3.6c1.8 0 3.5.8 4.7 2.1a6.2 6.2 0 0 1 4.7-2.1A4.7 4.7 0 0 1 21 8.4c0 3.5-3.1 6.3-8.2 11L12 21Z"
        fill={filled ? 'currentColor' : 'none'}
        stroke="currentColor"
        strokeWidth="1.6"
      />
    </svg>
  );
}

function ChatIcon() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true" className="h-5 w-5">
      <path
        d="M5 19.5V7.8A2.8 2.8 0 0 1 7.8 5h8.4A2.8 2.8 0 0 1 19 7.8v5.4A2.8 2.8 0 0 1 16.2 16H9L5 19.5Z"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinejoin="round"
      />
    </svg>
  );
}

function ShareIcon() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true" className="h-5 w-5">
      <path d="M14 4h6v6" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
      <path d="M20 4 11 13" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
      <path
        d="M19 12v5.2A1.8 1.8 0 0 1 17.2 19H6.8A1.8 1.8 0 0 1 5 17.2V6.8A1.8 1.8 0 0 1 6.8 5H12"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinecap="round"
      />
    </svg>
  );
}

function CloseIcon() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true" className="h-5 w-5">
      <path d="m6 6 12 12M18 6 6 18" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
    </svg>
  );
}

function AddPhotoIcon() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true" className="h-6 w-6">
      <rect x="3" y="5" width="18" height="14" rx="3" fill="none" stroke="currentColor" strokeWidth="1.6" />
      <path d="M8.2 13.8 10.9 11l3.3 3.4 2.1-2.1 2.2 2.5" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
      <path d="M12 8v3m-1.5-1.5h3" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
    </svg>
  );
}

export default function Home() {
  const { user, loading: authLoading } = useAuth();
  const router = useRouter();

  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [newPostContent, setNewPostContent] = useState('');
  const [newPostImage, setNewPostImage] = useState<File | null>(null);
  const [newPostImagePreview, setNewPostImagePreview] = useState('');
  const [commentText, setCommentText] = useState('');
  const [comments, setComments] = useState<Comment[]>([]);
  const [loadingComments, setLoadingComments] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [submittingComment, setSubmittingComment] = useState(false);
  const [deletingPostId, setDeletingPostId] = useState<string | null>(null);
  const [deletingCommentId, setDeletingCommentId] = useState<string | null>(null);
  const [composerOpen, setComposerOpen] = useState(false);
  const [selectedPostId, setSelectedPostId] = useState<string | null>(null);

  const loadPosts = useCallback(async () => {
    try {
      const response = await databases.listDocuments(DATABASE_ID, POSTS_COLLECTION_ID, [Query.orderDesc('$createdAt')]);
      setPosts(response.documents.map(normalizePost));
    } catch (error) {
      console.error('Error loading posts:', error);
    } finally {
      setLoading(false);
    }
  }, []);

  const loadComments = useCallback(async (postId: string) => {
    setLoadingComments(true);
    try {
      const response = await databases.listDocuments(DATABASE_ID, COMMENTS_COLLECTION_ID, [
        Query.equal('postId', postId),
        Query.orderDesc('$createdAt'),
      ]);
      setComments(response.documents.map(normalizeComment));
    } catch (error) {
      console.error('Error loading comments:', error);
      setComments([]);
    } finally {
      setLoadingComments(false);
    }
  }, []);

  useEffect(() => {
    if (!authLoading && !user) {
      router.push('/auth/signin');
      return;
    }

    if (user) {
      void loadPosts();
    }
  }, [authLoading, loadPosts, router, user]);

  useEffect(() => {
    if (!selectedPostId) {
      setComments([]);
      setCommentText('');
      return;
    }

    void loadComments(selectedPostId);
  }, [loadComments, selectedPostId]);

  useEffect(() => {
    return () => {
      if (newPostImagePreview) {
        URL.revokeObjectURL(newPostImagePreview);
      }
    };
  }, [newPostImagePreview]);

  const selectedPost = useMemo(
    () => posts.find((post) => post.$id === selectedPostId) ?? null,
    [posts, selectedPostId]
  );

  function resetComposer() {
    if (newPostImagePreview) {
      URL.revokeObjectURL(newPostImagePreview);
    }
    setNewPostContent('');
    setNewPostImage(null);
    setNewPostImagePreview('');
  }

  function closeComposer() {
    resetComposer();
    setComposerOpen(false);
  }

  function onImageSelected(file: File | null) {
    if (newPostImagePreview) {
      URL.revokeObjectURL(newPostImagePreview);
    }

    if (!file) {
      setNewPostImage(null);
      setNewPostImagePreview('');
      return;
    }

    setNewPostImage(file);
    setNewPostImagePreview(URL.createObjectURL(file));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!user || !newPostContent.trim()) return;

    setSubmitting(true);
    try {
      let imageId = '';

      if (newPostImage) {
        const uploaded = await storage.createFile(BUCKET_ID, ID.unique(), newPostImage);
        imageId = uploaded.$id;
      }

      await databases.createDocument(DATABASE_ID, POSTS_COLLECTION_ID, ID.unique(), {
        content: newPostContent.trim(),
        userId: user.$id,
        userName: user.name || 'Anonymous',
        likes: [],
        imageId,
      });

      closeComposer();
      await loadPosts();
    } catch (error) {
      console.error('Error creating post:', error);
    } finally {
      setSubmitting(false);
    }
  }

  async function handleLike(postId: string) {
    if (!user) return;

    try {
      const post = posts.find((entry) => entry.$id === postId);
      if (!post) return;

      const likes = post.likes || [];
      const isLiked = likes.includes(user.$id);
      const nextLikes = isLiked ? likes.filter((id) => id !== user.$id) : [...likes, user.$id];

      await databases.updateDocument(DATABASE_ID, POSTS_COLLECTION_ID, postId, { likes: nextLikes });
      await loadPosts();
    } catch (error) {
      console.error('Error liking post:', error);
    }
  }

  async function handleCreateComment(e: React.FormEvent) {
    e.preventDefault();
    if (!user || !selectedPostId || !commentText.trim()) return;

    setSubmittingComment(true);
    try {
      await databases.createDocument(DATABASE_ID, COMMENTS_COLLECTION_ID, ID.unique(), {
        postId: selectedPostId,
        content: commentText.trim(),
        userId: user.$id,
        userName: user.name || 'Anonymous',
      });

      setCommentText('');
      await loadComments(selectedPostId);
    } catch (error) {
      console.error('Error creating comment:', error);
    } finally {
      setSubmittingComment(false);
    }
  }

  async function handleDeletePost(post: Post) {
    if (!user || post.userId !== user.$id || deletingPostId) return;

    const shouldDelete = window.confirm('Delete this post? This also deletes comments on it.');
    if (!shouldDelete) return;

    setDeletingPostId(post.$id);
    try {
      const commentDocs = await databases.listDocuments(DATABASE_ID, COMMENTS_COLLECTION_ID, [
        Query.equal('postId', post.$id),
        Query.limit(100),
      ]);

      await Promise.all(
        commentDocs.documents.map((comment) =>
          databases.deleteDocument(DATABASE_ID, COMMENTS_COLLECTION_ID, comment.$id)
        )
      );

      if (post.imageId) {
        try {
          await storage.deleteFile(BUCKET_ID, post.imageId);
        } catch (error) {
          console.error('Error deleting image file:', error);
        }
      }

      await databases.deleteDocument(DATABASE_ID, POSTS_COLLECTION_ID, post.$id);
      if (selectedPostId === post.$id) {
        setSelectedPostId(null);
      }
      await loadPosts();
    } catch (error) {
      console.error('Error deleting post:', error);
    } finally {
      setDeletingPostId(null);
    }
  }

  async function handleDeleteComment(comment: Comment) {
    if (!user || comment.userId !== user.$id || deletingCommentId) return;

    const shouldDelete = window.confirm('Delete this comment?');
    if (!shouldDelete) return;

    setDeletingCommentId(comment.$id);
    try {
      await databases.deleteDocument(DATABASE_ID, COMMENTS_COLLECTION_ID, comment.$id);
      if (selectedPostId) {
        await loadComments(selectedPostId);
      }
    } catch (error) {
      console.error('Error deleting comment:', error);
    } finally {
      setDeletingCommentId(null);
    }
  }

  if (authLoading || loading) {
    return <div className="p-8 text-center text-[var(--on-surface-variant)]">Loading feed...</div>;
  }

  if (!user) return null;

  return (
    <div className="min-h-screen bg-[var(--background)] text-[var(--on-surface)] font-body">
      <Navbar onCompose={() => setComposerOpen(true)} />

      <main className="mx-auto max-w-3xl px-4 pb-24 pt-12 md:pb-28">
        <section className="mb-20">
          <h1 className="text-5xl font-extrabold tracking-tight text-[var(--on-surface)] font-headline">The Curated Feed</h1>
          <p className="mt-4 max-w-lg text-lg leading-relaxed text-[var(--on-surface-variant)] font-label">
            Share updates, images, and discussions in one clean feed.
          </p>
        </section>

        {posts.length === 0 ? (
          <section className="rounded-xl bg-[var(--surface-container-low)] px-6 py-20 text-center">
            <p className="text-sm uppercase tracking-[0.3em] text-[var(--outline)] font-label">No posts yet</p>
            <button
              type="button"
              onClick={() => setComposerOpen(true)}
              className="mt-6 rounded-xl bg-[var(--primary)] px-6 py-3 text-sm font-semibold text-[var(--on-primary)] transition hover:bg-[var(--primary-dim)]"
            >
              Create first post
            </button>
          </section>
        ) : (
          <div className="flex flex-col gap-24">
            {posts.map((post, index) => {
              const isLiked = post.likes.includes(user.$id);
              const tag = postTag(post.content);
              const hasImage = Boolean(post.imageId);
              const isOwner = post.userId === user.$id;
              const isDeletingThisPost = deletingPostId === post.$id;

              if (index % 3 === 1) {
                return (
                  <article key={post.$id} className="relative overflow-hidden rounded-xl bg-[var(--surface-container-low)] p-10">
                    <div className="pointer-events-none absolute right-8 top-6 text-7xl text-[var(--outline-variant)]/20">&quot;</div>
                    <p className="text-xs uppercase tracking-[0.25em] text-[var(--outline)] font-label">Thoughts • {post.userName}</p>
                    <h2 className="mt-6 text-3xl font-extrabold leading-tight tracking-tight text-[var(--on-surface)] font-headline">
                      &quot;{excerptTitle(post.content)}&quot;
                    </h2>
                    <p className="mt-4 line-clamp-4 text-base leading-relaxed text-[var(--on-surface-variant)]">{post.content}</p>
                    {hasImage ? (
                      <button
                        type="button"
                        onClick={() => setSelectedPostId(post.$id)}
                        className="mt-5 block overflow-hidden rounded-lg"
                      >
                        <img src={imageUrl(post.imageId)} alt={excerptTitle(post.content)} className="h-44 w-full object-cover transition hover:scale-[1.01]" />
                      </button>
                    ) : null}
                    <div className="mt-8 flex items-center gap-6">
                      <button
                        type="button"
                        onClick={() => handleLike(post.$id)}
                        className="inline-flex items-center gap-2 text-[var(--on-surface-variant)] transition hover:text-[var(--primary)]"
                      >
                        <HeartIcon filled={isLiked} />
                        <span className="text-xs font-bold font-label">{post.likes.length}</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => setSelectedPostId(post.$id)}
                        className="inline-flex items-center gap-2 text-[var(--on-surface-variant)] transition hover:text-[var(--primary)]"
                      >
                        <ChatIcon />
                        <span className="text-xs font-bold font-label">Discuss</span>
                      </button>
                      {isOwner ? (
                        <button
                          type="button"
                          onClick={() => handleDeletePost(post)}
                          disabled={isDeletingThisPost}
                          className="ml-auto inline-flex items-center rounded-lg border border-[var(--error-container)]/60 px-3 py-2 text-xs font-semibold uppercase tracking-[0.12em] text-[var(--error)] transition hover:bg-[var(--error-container)]/20 disabled:cursor-not-allowed disabled:opacity-50"
                        >
                          {isDeletingThisPost ? 'Deleting' : 'Delete'}
                        </button>
                      ) : null}
                    </div>
                  </article>
                );
              }

              return (
                <article key={post.$id} className="relative">
                  <div className="absolute -left-4 -top-5 z-10">
                    <div className="flex h-12 w-12 items-center justify-center rounded-full border-4 border-[var(--surface)] bg-[var(--surface-container-high)] text-xs font-bold text-[var(--primary)] shadow-sm">
                      {getInitials(post.userName)}
                    </div>
                  </div>

                  <div className="overflow-hidden rounded-xl bg-[var(--surface-container-lowest)]">
                    <button
                      type="button"
                      onClick={() => setSelectedPostId(post.$id)}
                      className="group block w-full text-left"
                    >
                      {hasImage ? (
                        <div className="aspect-[4/5] w-full overflow-hidden">
                          <img
                            src={imageUrl(post.imageId)}
                            alt={excerptTitle(post.content)}
                            className="h-full w-full object-cover transition duration-700 group-hover:scale-[1.02]"
                          />
                        </div>
                      ) : (
                        <div className={`aspect-[4/5] w-full bg-gradient-to-br ${colorBand(post.$id)} p-8 transition duration-700 group-hover:scale-[1.01]`}>
                          <div className="flex h-full items-end">
                            <div>
                              <p className="text-[11px] font-semibold uppercase tracking-[0.24em] text-[var(--on-surface-variant)]/85 font-label">Featured capture</p>
                              <p className="mt-3 max-w-md text-2xl font-extrabold leading-tight tracking-tight text-[var(--on-surface)] font-headline">
                                {excerptTitle(post.content)}
                              </p>
                            </div>
                          </div>
                        </div>
                      )}
                    </button>

                    <div className="space-y-4 p-8">
                      <div className="flex items-start justify-between gap-4">
                        <div>
                          <h2 className="text-xl font-bold tracking-tight text-[var(--on-surface)] font-headline">{excerptTitle(post.content)}</h2>
                          <p className="mt-1 text-xs uppercase tracking-[0.2em] text-[var(--outline)] font-label">
                            {post.userName} • {getTimeSince(post.$createdAt)}
                          </p>
                        </div>
                        <span className="rounded-full bg-[var(--tertiary-container)] px-3 py-1 text-xs font-bold tracking-wide text-[var(--on-tertiary-container)] font-label">
                          {tag}
                        </span>
                      </div>

                      <p className="line-clamp-4 text-base leading-relaxed text-[var(--on-surface-variant)]">{post.content}</p>

                      <div className="flex items-center gap-8 border-t border-[var(--outline-variant)]/25 pt-5">
                        <button
                          type="button"
                          onClick={() => handleLike(post.$id)}
                          className="inline-flex items-center gap-2 text-[var(--on-surface-variant)] transition hover:text-[var(--primary)]"
                        >
                          <HeartIcon filled={isLiked} />
                          <span className="text-xs font-bold font-label">{post.likes.length}</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => setSelectedPostId(post.$id)}
                          className="inline-flex items-center gap-2 text-[var(--on-surface-variant)] transition hover:text-[var(--primary)]"
                        >
                          <ChatIcon />
                          <span className="text-xs font-bold font-label">Discuss</span>
                        </button>
                        <button
                          type="button"
                          className="ml-auto inline-flex items-center gap-2 text-[var(--on-surface-variant)] transition hover:text-[var(--primary)]"
                        >
                          <ShareIcon />
                        </button>
                        {isOwner ? (
                          <button
                            type="button"
                            onClick={() => handleDeletePost(post)}
                            disabled={isDeletingThisPost}
                            className="inline-flex items-center rounded-lg border border-[var(--error-container)]/60 px-3 py-2 text-xs font-semibold uppercase tracking-[0.12em] text-[var(--error)] transition hover:bg-[var(--error-container)]/20 disabled:cursor-not-allowed disabled:opacity-50"
                          >
                            {isDeletingThisPost ? 'Deleting' : 'Delete'}
                          </button>
                        ) : null}
                      </div>
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </main>

      {composerOpen ? (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-[rgba(11,15,15,0.52)] backdrop-blur-sm">
          <div className="min-h-screen px-4 py-8 sm:px-6 sm:py-12">
            <div className="mx-auto max-w-2xl rounded-2xl bg-[var(--surface)] p-6 sm:p-10">
              <div className="flex items-center justify-between gap-4">
                <div>
                  <h2 className="text-4xl font-extrabold tracking-tight text-[var(--on-surface)] font-headline">Create Moment</h2>
                  <p className="mt-2 text-sm tracking-wide text-[var(--on-surface-variant)] font-label">SHARE YOUR VISUAL STORY WITH THE GALLERY</p>
                </div>
                <button
                  type="button"
                  onClick={closeComposer}
                  className="inline-flex h-10 w-10 items-center justify-center rounded-full text-[var(--outline)] transition hover:bg-[var(--surface-container-low)] hover:text-[var(--on-surface)]"
                  aria-label="Close"
                >
                  <CloseIcon />
                </button>
              </div>

              <form onSubmit={handleSubmit} className="mt-8 space-y-8">
                <div className="relative rounded-xl bg-[var(--surface-container-low)] p-2">
                  <textarea
                    value={newPostContent}
                    onChange={(e) => setNewPostContent(e.target.value)}
                    placeholder="What&apos;s on your mind?"
                    className="min-h-[220px] w-full resize-none rounded-xl border-0 bg-transparent p-6 text-xl text-[var(--on-surface)] outline-none placeholder:text-[var(--outline-variant)]"
                    maxLength={500}
                    required
                  />
                  <span className="absolute bottom-5 right-6 text-xs text-[var(--outline-variant)] font-label">{newPostContent.length}/500</span>
                </div>

                <div className="grid grid-cols-1 gap-4 md:grid-cols-12">
                  <div className="md:col-span-8">
                    <label className="block cursor-pointer overflow-hidden rounded-xl bg-[var(--surface-container-low)] p-6">
                      {newPostImagePreview ? (
                        <img src={newPostImagePreview} alt="Preview" className="aspect-video w-full rounded-lg object-cover" />
                      ) : (
                        <div className="flex aspect-video flex-col items-center justify-center gap-3 text-center">
                          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-[var(--surface-container-lowest)] text-[var(--primary)]">
                            <AddPhotoIcon />
                          </div>
                          <span className="text-xs font-semibold uppercase tracking-[0.2em] text-[var(--primary)] font-label">Add image</span>
                        </div>
                      )}
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) => {
                          onImageSelected(e.target.files?.[0] ?? null);
                        }}
                      />
                    </label>
                  </div>
                  <div className="space-y-4 md:col-span-4">
                    <div className="rounded-xl bg-[var(--tertiary-container)]/35 p-5 text-xs font-semibold leading-relaxed text-[var(--on-tertiary-container)] font-label">
                      Upload an image to publish visual posts like your stitched feed examples.
                    </div>
                    <div className="rounded-xl bg-[var(--secondary-container)]/35 p-5 text-xs font-semibold leading-relaxed text-[var(--on-secondary-container)] font-label">
                      Posting still works without an image.
                    </div>
                    {newPostImage ? (
                      <button
                        type="button"
                        onClick={() => onImageSelected(null)}
                        className="w-full rounded-lg border border-[var(--outline-variant)]/60 px-3 py-2 text-xs font-semibold uppercase tracking-[0.15em] text-[var(--on-surface-variant)] transition hover:bg-[var(--surface-container-low)]"
                      >
                        Remove image
                      </button>
                    ) : null}
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <span className="mr-2 text-xs uppercase tracking-[0.2em] text-[var(--outline-variant)] font-label">Suggested tags:</span>
                  {['#minimalist', '#gallery', '#editorial'].map((tag) => (
                    <button
                      key={tag}
                      type="button"
                      onClick={() => {
                        setNewPostContent((current) => `${current}${current.trim() ? ' ' : ''}${tag}`);
                      }}
                      className="rounded-full bg-[var(--surface-container-high)] px-4 py-1.5 text-xs text-[var(--on-surface)] transition hover:bg-[var(--outline-variant)]/20"
                    >
                      {tag}
                    </button>
                  ))}
                </div>

                <div className="flex justify-center pt-2">
                  <button
                    type="submit"
                    disabled={submitting || !newPostContent.trim()}
                    className="rounded-xl bg-gradient-to-br from-[var(--primary)] to-[var(--primary-dim)] px-14 py-4 text-lg font-bold text-[var(--on-primary)] shadow-[0_12px_40px_rgba(45,52,51,0.12)] transition hover:scale-[1.01] disabled:cursor-not-allowed disabled:opacity-50"
                  >
                    {submitting ? 'Posting...' : 'Post to Gallery'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      ) : null}

      {selectedPost ? (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-[rgba(11,15,15,0.56)] backdrop-blur-sm">
          <div className="mx-auto grid min-h-screen max-w-screen-xl grid-cols-1 gap-8 px-4 py-8 sm:px-6 lg:grid-cols-12 lg:gap-12">
            <div className="lg:col-span-7">
              <div className="sticky top-8 overflow-hidden rounded-xl bg-[var(--surface-container-lowest)] shadow-[0_12px_40px_rgba(45,52,51,0.08)]">
                {selectedPost.imageId ? (
                  <img src={imageUrl(selectedPost.imageId)} alt={excerptTitle(selectedPost.content)} className="aspect-[4/5] w-full object-cover" />
                ) : (
                  <div className={`aspect-[4/5] w-full bg-gradient-to-br ${colorBand(selectedPost.$id)} p-8`}>
                    <div className="flex h-full items-end">
                      <p className="max-w-xl text-4xl font-extrabold leading-tight tracking-tight text-[var(--on-surface)] font-headline">
                        {excerptTitle(selectedPost.content)}
                      </p>
                    </div>
                  </div>
                )}
                <div className="border-t border-[var(--outline-variant)]/20 px-6 py-4 text-sm text-[var(--on-surface-variant)] font-label">
                  Captured in the community archive
                </div>
              </div>
            </div>

            <div className="space-y-8 lg:col-span-5">
              <div className="flex items-start justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-[var(--surface-container-high)] text-sm font-bold text-[var(--primary)]">
                    {getInitials(selectedPost.userName)}
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-[var(--on-surface)] font-headline">{selectedPost.userName}</h3>
                    <p className="text-xs uppercase tracking-[0.2em] text-[var(--outline)] font-label">{getTimeSince(selectedPost.$createdAt)}</p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => setSelectedPostId(null)}
                  className="inline-flex h-10 w-10 items-center justify-center rounded-full text-[var(--outline)] transition hover:bg-[var(--surface-container-low)] hover:text-[var(--on-surface)]"
                  aria-label="Close detail"
                >
                  <CloseIcon />
                </button>
              </div>
              {selectedPost.userId === user.$id ? (
                <button
                  type="button"
                  onClick={() => handleDeletePost(selectedPost)}
                  disabled={deletingPostId === selectedPost.$id}
                  className="rounded-lg border border-[var(--error-container)]/60 px-3 py-2 text-xs font-semibold uppercase tracking-[0.12em] text-[var(--error)] transition hover:bg-[var(--error-container)]/20 disabled:cursor-not-allowed disabled:opacity-50"
                >
                  {deletingPostId === selectedPost.$id ? 'Deleting post' : 'Delete post'}
                </button>
              ) : null}

              <section className="space-y-5">
                <h4 className="text-3xl font-extrabold leading-tight tracking-tight text-[var(--on-surface)] font-headline">
                  {excerptTitle(selectedPost.content)}
                </h4>
                <p className="whitespace-pre-wrap text-lg leading-relaxed text-[var(--on-surface-variant)]">{selectedPost.content}</p>
                <div className="flex flex-wrap gap-2">
                  <span className="rounded-full bg-[var(--tertiary-container)] px-3 py-1 text-xs font-medium text-[var(--on-tertiary-container)]">#{postTag(selectedPost.content).toLowerCase()}</span>
                  <span className="rounded-full bg-[var(--surface-container-high)] px-3 py-1 text-xs font-medium text-[var(--on-surface-variant)]">{formatPostDate(selectedPost.$createdAt)}</span>
                </div>
              </section>

              <div className="flex items-center gap-6 border-t border-[var(--outline-variant)]/20 pt-5 text-sm text-[var(--outline)]">
                <button
                  type="button"
                  onClick={() => handleLike(selectedPost.$id)}
                  className="inline-flex items-center gap-2 transition hover:text-[var(--primary)]"
                >
                  <HeartIcon filled={selectedPost.likes.includes(user.$id)} />
                  <span className="font-semibold">{selectedPost.likes.length}</span>
                </button>
                <button type="button" className="inline-flex items-center gap-2 transition hover:text-[var(--primary)]">
                  <ChatIcon />
                  <span className="font-semibold">{comments.length}</span>
                </button>
                <button type="button" className="inline-flex items-center gap-2 transition hover:text-[var(--primary)]">
                  <ShareIcon />
                  <span className="font-semibold">Share</span>
                </button>
              </div>

              <section className="space-y-4 border-t border-[var(--outline-variant)]/20 pt-8">
                <h5 className="text-xl font-bold text-[var(--on-surface)] font-headline">Community Notes</h5>

                <form onSubmit={handleCreateComment} className="rounded-2xl bg-[var(--surface-container-low)] p-3">
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-full bg-[var(--surface-container-high)] text-xs font-bold text-[var(--primary)]">
                      {getInitials(user.name || 'You')}
                    </div>
                    <input
                      type="text"
                      value={commentText}
                      onChange={(e) => setCommentText(e.target.value)}
                      placeholder="Write a clean response..."
                      className="flex-1 rounded-xl border-0 bg-[var(--surface-container-lowest)] px-4 py-3 text-sm outline-none"
                      maxLength={1000}
                    />
                    <button
                      type="submit"
                      disabled={submittingComment || !commentText.trim()}
                      className="rounded-xl bg-[var(--primary)] px-4 py-3 text-xs font-semibold uppercase tracking-[0.12em] text-[var(--on-primary)] transition hover:bg-[var(--primary-dim)] disabled:cursor-not-allowed disabled:opacity-50"
                    >
                      {submittingComment ? 'Posting' : 'Post'}
                    </button>
                  </div>
                </form>

                {loadingComments ? (
                  <p className="text-sm text-[var(--on-surface-variant)]">Loading comments...</p>
                ) : comments.length === 0 ? (
                  <p className="text-sm text-[var(--on-surface-variant)]">No comments yet. Be the first to comment.</p>
                ) : (
                  <div className="space-y-4">
                    {comments.map((comment) => (
                      <div key={comment.$id} className="rounded-2xl bg-[var(--surface-container-lowest)] p-4 shadow-[0_8px_24px_rgba(45,52,51,0.05)]">
                        <div className="flex items-center justify-between gap-2">
                          <p className="text-sm font-semibold text-[var(--on-surface)] font-label">{comment.userName}</p>
                          <div className="flex items-center gap-3">
                            <p className="text-xs text-[var(--outline)] font-label">{getTimeSince(comment.$createdAt)}</p>
                            {comment.userId === user.$id ? (
                              <button
                                type="button"
                                onClick={() => handleDeleteComment(comment)}
                                disabled={deletingCommentId === comment.$id}
                                className="rounded-md border border-[var(--error-container)]/60 px-2 py-1 text-[10px] font-semibold uppercase tracking-[0.1em] text-[var(--error)] transition hover:bg-[var(--error-container)]/20 disabled:cursor-not-allowed disabled:opacity-50"
                              >
                                {deletingCommentId === comment.$id ? 'Deleting' : 'Delete'}
                              </button>
                            ) : null}
                          </div>
                        </div>
                        <p className="mt-2 whitespace-pre-wrap text-sm leading-relaxed text-[var(--on-surface-variant)]">{comment.content}</p>
                      </div>
                    ))}
                  </div>
                )}
              </section>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}
