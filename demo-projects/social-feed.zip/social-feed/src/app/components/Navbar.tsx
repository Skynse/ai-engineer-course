'use client';

import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { signOut } from '@/lib/auth';
import { useAuth } from './AuthProvider';

function PlusSquareIcon() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true" className="h-5 w-5">
      <rect x="3" y="3" width="18" height="18" rx="4" fill="none" stroke="currentColor" strokeWidth="1.7" />
      <path d="M12 7.5V16.5M7.5 12H16.5" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" />
    </svg>
  );
}

export default function Navbar({ onCompose }: { onCompose: () => void }) {
  const { user, refreshUser } = useAuth();
  const router = useRouter();

  const handleSignOut = async () => {
    await signOut();
    await refreshUser();
    router.push('/auth/signin');
  };

  return (
    <header className="sticky top-0 z-40 border-b border-[var(--outline-variant)]/40 bg-[var(--surface)]/94 backdrop-blur-xl">
      <div className="mx-auto flex w-full max-w-screen-xl items-center justify-between px-4 py-4 sm:px-6">
        <div className="flex items-center">
          <Link href="/" className="text-2xl font-extrabold tracking-tight text-[var(--primary)] font-headline">
            Gallery
          </Link>
        </div>

        <div className="flex items-center gap-2 sm:gap-3">
          {user ? (
            <>
              <button
                type="button"
                onClick={onCompose}
                className="inline-flex h-10 w-10 items-center justify-center rounded-full text-[var(--primary)] transition hover:bg-[var(--surface-container-low)]"
                aria-label="Create post"
              >
                <PlusSquareIcon />
              </button>
              <span className="hidden rounded-full border border-[var(--outline-variant)]/60 bg-[var(--surface-container-lowest)] px-4 py-2 text-sm font-medium text-[var(--on-surface)] sm:inline-block">
                {user.name}
              </span>
              <button
                type="button"
                onClick={handleSignOut}
                className="rounded-xl bg-[var(--primary)] px-3 py-2 text-sm font-semibold text-[var(--on-primary)] transition hover:bg-[var(--primary-dim)]"
              >
                Sign out
              </button>
            </>
          ) : (
            <>
              <Link href="/auth/signin" className="text-sm font-medium text-[var(--outline)]">
                Sign in
              </Link>
              <Link
                href="/auth/signup"
                className="rounded-xl bg-[var(--primary)] px-3 py-2 text-sm font-semibold text-[var(--on-primary)] transition hover:bg-[var(--primary-dim)]"
              >
                Join
              </Link>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
