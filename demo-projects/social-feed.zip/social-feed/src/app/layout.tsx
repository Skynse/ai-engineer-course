import type { Metadata } from 'next';
import './globals.css';
import { AuthProvider } from './components/AuthProvider';

export const metadata: Metadata = {
  title: 'Social Feed',
  description: 'Share your thoughts with the community',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="min-h-full bg-[#f4fbff] antialiased">
        <AuthProvider>{children}</AuthProvider>
      </body>
    </html>
  );
}
