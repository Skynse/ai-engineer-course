'use client';

import { useState } from 'react';
import { signIn } from '@/lib/auth';
import { useAuth } from '@/app/components/AuthProvider';
import Link from 'next/link';
import { useRouter } from 'next/navigation';

function getErrorMessage(error: unknown) {
  return error instanceof Error ? error.message : 'Failed to sign in';
}

export default function SignIn() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const router = useRouter();
  const { refreshUser } = useAuth();

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      await signIn(email, password);
      await refreshUser();
      router.push('/');
    } catch (err: unknown) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-[radial-gradient(circle_at_top_left,_rgba(31,119,180,0.16),_transparent_30%),radial-gradient(circle_at_bottom_right,_rgba(255,107,87,0.14),_transparent_28%),linear-gradient(180deg,_#f4fbff,_#edf6fb)] px-4 py-10">
      <div className="w-full max-w-md rounded-[2rem] border border-[#dce7ef] bg-[rgba(255,255,255,0.92)] p-8 shadow-[0_30px_80px_rgba(15,59,87,0.12)]">
        <p className="text-sm font-semibold uppercase tracking-[0.34em] text-[#1b6f9b]">Pulseboard</p>
        <h2 className="mt-4 text-4xl font-black tracking-tight text-[#0f3b57]">Plug back into the feed.</h2>
        <p className="mt-3 text-sm leading-6 text-[#4c7a95]">Sign in to post updates, test interactions, and make the demo feel alive instead of generic.</p>

        {error && <div className="mt-6 rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">{error}</div>}

        <form onSubmit={handleSubmit} className="mt-8 space-y-5">
          <div>
            <label className="mb-2 block text-sm font-semibold text-[#27506a]">Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full rounded-2xl border border-[#dce7ef] bg-white px-4 py-3 text-[#0f3b57] outline-none transition focus:border-[#1b6f9b] focus:ring-4 focus:ring-sky-100"
              placeholder="you@example.com"
              required
            />
          </div>

          <div>
            <label className="mb-2 block text-sm font-semibold text-[#27506a]">Password</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full rounded-2xl border border-[#dce7ef] bg-white px-4 py-3 text-[#0f3b57] outline-none transition focus:border-[#1b6f9b] focus:ring-4 focus:ring-sky-100"
              placeholder="••••••••"
              required
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full rounded-full bg-[#0f3b57] px-5 py-3 text-sm font-bold uppercase tracking-[0.22em] text-white transition hover:bg-[#0c2f45] disabled:opacity-50"
          >
            {loading ? 'Signing In...' : 'Enter Feed'}
          </button>
        </form>

        <p className="mt-6 text-center text-sm text-[#4c7a95]">
          Don&apos;t have an account?{' '}
          <Link href="/auth/signup" className="font-semibold text-[#ff6b57] underline decoration-[#8ed1f0] underline-offset-4">
            Sign up
          </Link>
        </p>
      </div>
    </div>
  );
}
