export interface Post {
  $id: string;
  content: string;
  userId: string;
  userName: string;
  likes: string[];
  $createdAt: string;
  $updatedAt: string;
}

export interface CreatePostInput {
  content: string;
  userId: string;
  userName: string;
}
