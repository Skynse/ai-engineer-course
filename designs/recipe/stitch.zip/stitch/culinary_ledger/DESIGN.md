# Design System Document: The Culinary Ledger

## 1. Overview & Creative North Star
**Creative North Star: "The Architectural Mise en Place"**

This design system moves away from the cluttered, ad-filled nature of modern recipe sites, opting instead for the precision of a professional kitchen tool and the soul of a chef’s private notebook. It is characterized by **Structured Whitespace** and **Tonal Depth**. 

Instead of using traditional "app" metaphors (heavy shadows, rounded buttons, colorful headers), we treat the UI as a series of high-end paper stocks and stone surfaces. The design breaks the template through **Intentional Asymmetry**—for example, using large `display-sm` typography for recipe titles that bleed slightly off-center, paired with strictly utilitarian `label-md` data points. The goal is a high-end editorial feel that remains "invisible" so the user can focus on the craft of cooking.

---

## 2. Colors & Surface Philosophy
The palette is a study in "Warm Neutrals" and "Herbaceous Accents," utilizing the Material Design tokens to create a sophisticated, non-linear hierarchy.

### The "No-Line" Rule
Prohibit the use of `1px solid` borders for sectioning. We define boundaries through background color shifts. A section for "Ingredients" should sit on `surface-container-low` (#f2f4f4), while the "Instructions" section transitions to `surface` (#f9f9f9). This creates a "blocked" look that feels architectural rather than boxed-in.

### Surface Hierarchy & Nesting
Treat the UI as a physical stack of prep cards.
- **Base Layer:** `surface` (#f9f9f9)
- **Secondary Grouping:** `surface-container` (#ebeeef)
- **Active/Floating Elements:** `surface-container-lowest` (#ffffff)
Use `surface-container-highest` (#dde4e5) only for small, high-contrast utility areas like a sidebar or a "Kitchen Timer" drawer.

### The "Glass & Gradient" Rule
To elevate the "Digital Notebook" vibe, floating action buttons or sticky headers should utilize **Glassmorphism**. Apply `surface` at 80% opacity with a `16px` backdrop blur. For main CTA buttons (e.g., "Start Cooking"), use a subtle linear gradient from `primary` (#1b6d24) to `primary_dim` (#076019) at a 145-degree angle to give the button a "weighted" feel like a heavy-duty kitchen appliance.

---

## 3. Typography
Typography is the primary engine of this design system. We use **Inter** exclusively, leaning on its variable weights to create an editorial rhythm.

*   **Editorial Authority:** Use `display-sm` (2.25rem) for recipe titles. Set them with a negative letter-spacing (-0.02em) to feel like a printed cookbook.
*   **The Utilitarian Grid:** Use `label-md` (0.75rem) in all-caps with increased letter-spacing (+0.05em) for metadata like "PREP TIME," "CALORIES," or "DIFFICULTY."
*   **The Reading Experience:** `body-lg` (1rem) is reserved for cooking instructions. Use a line-height of `1.6` to ensure legibility when the phone is sitting on a distant countertop.
*   **Contrast as Navigation:** Use `on_surface_variant` (#5a6061) for secondary descriptions to ensure the `primary` content stands out without needing bold weights.

---

## 4. Elevation & Depth
We eschew traditional drop shadows for **Tonal Layering**.

*   **The Layering Principle:** Instead of a shadow, place a `surface-container-lowest` (#ffffff) card on a `surface-container-low` (#f2f4f4) background. This "lift" is achieved purely through color value.
*   **Ambient Shadows:** If a component must float (e.g., a modal or a floating timer), use a "Kitchen Ambient" shadow: `box-shadow: 0 12px 32px -4px rgba(45, 52, 53, 0.08)`. It should feel like a soft shadow cast by overhead kitchen lighting.
*   **The Ghost Border:** If a boundary is strictly required for accessibility, use the `outline_variant` (#adb3b4) at **15% opacity**. This creates a "whisper" of a line that guides the eye without cluttering the canvas.

---

## 5. Components

### Buttons
*   **Primary:** Gradient fill (`primary` to `primary_dim`), `on_primary` text. Roundedness: `md` (0.375rem).
*   **Secondary:** `surface-container-high` (#e4e9ea) fill with `on_surface` text. No border.
*   **Tertiary:** Ghost style. `label-md` text weight, no background, `primary` text color.

### Input Fields
*   **The "Ledger" Style:** No containing box. Use a bottom border of `outline_variant` at 20% opacity. When focused, transition the bottom border to `primary` (#1b6d24) at 2px thickness. This mimics a lined notebook.

### Cards & Lists
*   **The "No-Divider" Rule:** Forbid 1px dividers between list items. Use the **Spacing Scale** `3` (1rem) to create clear separation. For ingredient lists, use a subtle `surface-container-low` background on every second item (zebra striping) to aid tracking while cooking.

### Specialized Component: The "Active Step" Card
*   A large-format card using `surface-container-lowest` (#ffffff). Apply a `primary` (#1b6d24) left-accent bar (4px wide). Use `headline-sm` for the instruction text to ensure the user can read it from 3 feet away.

---

## 6. Do's and Don'ts

### Do
*   **Do** use asymmetrical margins. For example, a wider left margin (Spacing `8`) and a tighter right margin (Spacing `4`) to mimic the gutter of a book.
*   **Do** use `primary_container` (#a3f69c) for "Success" states or "Completed" ingredients; it feels like a highlighter marker on paper.
*   **Do** prioritize `surface-bright` for the main canvas to keep the "Kitchen Tool" vibe feeling hygienic and clean.

### Don't
*   **Don't** use pure black (#000000). Always use `on_surface` (#2d3435) for text to maintain a high-end, ink-on-paper feel.
*   **Don't** use `rounded-full` (pills) for functional buttons. Stick to `md` (0.375rem) to maintain a precise, architectural silhouette.
*   **Don't** use standard Material icons in multi-color. All iconography should be thin-stroke (2pt) and monochromatic using `on_surface_variant`.