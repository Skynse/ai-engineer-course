# Design System Strategy: The Editorial Ethos

## 1. Overview & Creative North Star
The Creative North Star for this design system is **"The Curated Gallery."** 

Unlike traditional social media platforms that overwhelm the user with "noise" and dense information clusters, this system treats every post, profile, and interaction as a piece of art in a high-end digital gallery. We break the "template" look by prioritizing **intentional asymmetry** and **expansive whitespace**. 

Instead of a rigid, boxed-in grid, we utilize the "Breathing Grid" philosophy: elements are anchored by generous margins (`spacing.16` to `spacing.24`) and staggered alignments that guide the eye through a narrative rather than a list. The interface should feel less like a software tool and more like a premium, tactile publication.

---

## 2. Colors & Tonal Depth
Our palette is a study in subtlety. We avoid the harshness of pure black and instead use a sophisticated range of muted greens and soft grays to create a "serene" digital environment.

### The "No-Line" Rule
**Explicit Instruction:** Do not use 1px solid borders for sectioning or containment. 
Boundaries must be defined solely through background color shifts. For example, a feed of posts should sit as `surface-container-lowest` cards atop a `surface` background. To separate a sidebar from the main content, use a shift from `surface` to `surface-container-low`.

### Surface Hierarchy & Nesting
Treat the UI as a series of physical layers. We use the surface-container tiers to create depth without shadows:
*   **Base Layer:** `surface` (#f8faf9) — The canvas.
*   **Secondary Context:** `surface-container-low` (#f1f4f3) — For navigation rails or secondary feeds.
*   **Interactive Focus:** `surface-container-lowest` (#ffffff) — For primary cards or active input fields.
*   **Elevated Overlays:** `surface-container-high` (#e4e9e8) — For subtle callouts or temporary states.

### The "Glass & Gradient" Rule
To add "soul" to the minimalism, we move beyond flat hex codes:
*   **Main CTAs:** Use a subtle linear gradient from `primary` (#49645e) to `primary-dim` (#3e5852) at a 135-degree angle. This prevents the "flat-button" look and adds a premium, satin-like finish.
*   **Floating Navigation:** Apply `backdrop-blur: 20px` to any floating elements using a semi-transparent version of `surface-bright` (80% opacity).

---

## 3. Typography: Editorial Authority
We utilize a dual-sans-serif approach to create a sophisticated hierarchy that feels both modern and authoritative.

*   **Display & Headlines (Manrope):** These are our "hero" elements. Use `display-lg` and `headline-lg` with tight letter-spacing (-0.02em) to create high-impact, editorial titles.
*   **Body (Manrope):** Optimized for readability. `body-lg` at 1rem is the standard for user-generated content, ensuring the "airy" feel is maintained even in long-form text.
*   **Labels (Plus Jakarta Sans):** We switch to Plus Jakarta Sans for `label-md` and `label-sm`. This slight shift in typeface for metadata (timestamps, tag names) provides a "technical" contrast to the expressive body text, making the platform feel organized and engineered.

---

## 4. Elevation & Depth: Tonal Layering
Traditional structural lines are replaced by the **Layering Principle**. 

*   **Ambient Shadows:** If an element must float (like a Modal or FAB), do not use a standard gray shadow. Use a diffused shadow: `box-shadow: 0 12px 40px rgba(45, 52, 51, 0.06)`. The tint is derived from `on-surface` to ensure the shadow feels like a natural obstruction of light on a sage-tinted surface.
*   **The "Ghost Border" Fallback:** In high-density utility areas (like a complex settings page), if a container needs a border, use `outline-variant` (#acb3b2) at **15% opacity**. It should be felt, not seen.
*   **Soft Transitions:** All state changes (hover, focus) should use a `300ms cubic-bezier(0.4, 0, 0.2, 1)` transition. The movement should feel "liquid," not mechanical.

---

## 5. Component Guidelines

### Buttons (The Statement Piece)
*   **Primary:** Gradient of `primary` to `primary-dim`. Roundedness: `md` (0.375rem). No border.
*   **Secondary:** `surface-container-highest` background with `on-surface` text. 
*   **Tertiary/Ghost:** No background. Underline only on hover using a 2px `primary-fixed-dim` stroke.

### Cards & Feed Items
*   **Structure:** Absolutely no dividers. Separate posts using `spacing.10` or `spacing.12`.
*   **Background:** Use `surface-container-lowest`. 
*   **Asymmetry:** Encourage "Editorial Offsetting." Place the user's avatar (`rounded-full`) slightly overlapping the top-left edge of the card to break the square container.

### Input Fields
*   **Default State:** `surface-container-low` background, no border.
*   **Focus State:** Shift to `surface-container-lowest` with a 1px "Ghost Border" of `primary` at 30% opacity. This subtle glow signals intent without clutter.

### Signature Components for Social Media
*   **The "Moment" Chip:** For trending topics, use `tertiary-container` with `on-tertiary-container` text. This soft blue-cyan provides a "cool" focal point against the sage-green primary theme.
*   **Whitespace Dividers:** Use `spacing.20` of empty space between major page sections instead of a horizontal rule.

---

## 6. Do’s and Don’ts

### Do
*   **DO** use `surface-container-highest` for hover states on list items.
*   **DO** allow images to span the full width of their containers, removing internal padding to emphasize the "Gallery" feel.
*   **DO** use `display-sm` for empty states to make them feel like intentional design moments rather than "missing" content.

### Don't
*   **DON'T** use 100% black (#000000). Use `on-surface` (#2d3433) for all primary text to maintain the soft, organic tone.
*   **DON'T** use `rounded-none`. Everything must have at least `DEFAULT` (0.25rem) or `md` (0.375rem) corner radius to keep the "Soft Minimalist" promise.
*   **DON'T** crowd the edges. If a container is close to the screen edge, increase the padding using `spacing.6` or `spacing.8`.